(function () {

/* Imports */
var Blaze = Package.blaze.Blaze;
var UI = Package.blaze.UI;
var Handlebars = Package.blaze.Handlebars;



/* Exports */
Package._define("ui", {
  Blaze: Blaze,
  UI: UI,
  Handlebars: Handlebars
});

})();
