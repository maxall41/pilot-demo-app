(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var check = Package.check.check;
var Match = Package.check.Match;
var ECMAScript = Package.ecmascript.ECMAScript;
var URL = Package.url.URL;
var URLSearchParams = Package.url.URLSearchParams;
var RoutePolicy = Package.routepolicy.RoutePolicy;
var WebApp = Package.webapp.WebApp;
var WebAppInternals = Package.webapp.WebAppInternals;
var main = Package.webapp.main;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var ServiceConfiguration = Package['service-configuration'].ServiceConfiguration;
var Log = Package.logging.Log;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var OAuth, OAuthTest;

var require = meteorInstall({"node_modules":{"meteor":{"oauth":{"oauth_server.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/oauth/oauth_server.js                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let bodyParser;
module.link("body-parser", {
  default(v) {
    bodyParser = v;
  }

}, 0);
OAuth = {};
OAuthTest = {};
RoutePolicy.declare('/_oauth/', 'network');
const registeredServices = {}; // Internal: Maps from service version to handler function. The
// 'oauth1' and 'oauth2' packages manipulate this directly to register
// for callbacks.

OAuth._requestHandlers = {}; // Register a handler for an OAuth service. The handler will be called
// when we get an incoming http request on /_oauth/{serviceName}. This
// handler should use that information to fetch data about the user
// logging in.
//
// @param name {String} e.g. "google", "facebook"
// @param version {Number} OAuth version (1 or 2)
// @param urls   For OAuth1 only, specify the service's urls
// @param handleOauthRequest {Function(oauthBinding|query)}
//   - (For OAuth1 only) oauthBinding {OAuth1Binding} bound to the appropriate provider
//   - (For OAuth2 only) query {Object} parameters passed in query string
//   - return value is:
//     - {serviceData:, (optional options:)} where serviceData should end
//       up in the user's services[name] field
//     - `null` if the user declined to give permissions
//

OAuth.registerService = (name, version, urls, handleOauthRequest) => {
  if (registeredServices[name]) throw new Error("Already registered the ".concat(name, " OAuth service"));
  registeredServices[name] = {
    serviceName: name,
    version,
    urls,
    handleOauthRequest
  };
}; // For test cleanup.


OAuthTest.unregisterService = name => {
  delete registeredServices[name];
};

OAuth.retrieveCredential = (credentialToken, credentialSecret) => OAuth._retrievePendingCredential(credentialToken, credentialSecret); // The state parameter is normally generated on the client using
// `btoa`, but for tests we need a version that runs on the server.
//


OAuth._generateState = (loginStyle, credentialToken, redirectUrl) => {
  return Buffer.from(JSON.stringify({
    loginStyle: loginStyle,
    credentialToken: credentialToken,
    redirectUrl: redirectUrl
  })).toString('base64');
};

OAuth._stateFromQuery = query => {
  let string;

  try {
    string = Buffer.from(query.state, 'base64').toString('binary');
  } catch (e) {
    Log.warn("Unable to base64 decode state from OAuth query: ".concat(query.state));
    throw e;
  }

  try {
    return JSON.parse(string);
  } catch (e) {
    Log.warn("Unable to parse state from OAuth query: ".concat(string));
    throw e;
  }
};

OAuth._loginStyleFromQuery = query => {
  let style; // For backwards-compatibility for older clients, catch any errors
  // that result from parsing the state parameter. If we can't parse it,
  // set login style to popup by default.

  try {
    style = OAuth._stateFromQuery(query).loginStyle;
  } catch (err) {
    style = "popup";
  }

  if (style !== "popup" && style !== "redirect") {
    throw new Error("Unrecognized login style: ".concat(style));
  }

  return style;
};

OAuth._credentialTokenFromQuery = query => {
  let state; // For backwards-compatibility for older clients, catch any errors
  // that result from parsing the state parameter. If we can't parse it,
  // assume that the state parameter's value is the credential token, as
  // it used to be for older clients.

  try {
    state = OAuth._stateFromQuery(query);
  } catch (err) {
    return query.state;
  }

  return state.credentialToken;
};

OAuth._isCordovaFromQuery = query => {
  try {
    return !!OAuth._stateFromQuery(query).isCordova;
  } catch (err) {
    // For backwards-compatibility for older clients, catch any errors
    // that result from parsing the state parameter. If we can't parse
    // it, assume that we are not on Cordova, since older Meteor didn't
    // do Cordova.
    return false;
  }
}; // Checks if the `redirectUrl` matches the app host.
// We export this function so that developers can override this
// behavior to allow apps from external domains to login using the
// redirect OAuth flow.


OAuth._checkRedirectUrlOrigin = redirectUrl => {
  const appHost = Meteor.absoluteUrl();
  const appHostReplacedLocalhost = Meteor.absoluteUrl(undefined, {
    replaceLocalhost: true
  });
  return redirectUrl.substr(0, appHost.length) !== appHost && redirectUrl.substr(0, appHostReplacedLocalhost.length) !== appHostReplacedLocalhost;
};

const middleware = (req, res, next) => {
  let requestData; // Make sure to catch any exceptions because otherwise we'd crash
  // the runner

  try {
    const serviceName = oauthServiceName(req);

    if (!serviceName) {
      // not an oauth request. pass to next middleware.
      next();
      return;
    }

    const service = registeredServices[serviceName]; // Skip everything if there's no service set by the oauth middleware

    if (!service) throw new Error("Unexpected OAuth service ".concat(serviceName)); // Make sure we're configured

    ensureConfigured(serviceName);
    const handler = OAuth._requestHandlers[service.version];
    if (!handler) throw new Error("Unexpected OAuth version ".concat(service.version));

    if (req.method === 'GET') {
      requestData = req.query;
    } else {
      requestData = req.body;
    }

    handler(service, requestData, res);
  } catch (err) {
    var _requestData;

    // if we got thrown an error, save it off, it will get passed to
    // the appropriate login call (if any) and reported there.
    //
    // The other option would be to display it in the popup tab that
    // is still open at this point, ignoring the 'close' or 'redirect'
    // we were passed. But then the developer wouldn't be able to
    // style the error or react to it in any way.
    if ((_requestData = requestData) !== null && _requestData !== void 0 && _requestData.state && err instanceof Error) {
      try {
        // catch any exceptions to avoid crashing runner
        OAuth._storePendingCredential(OAuth._credentialTokenFromQuery(requestData), err);
      } catch (err) {
        // Ignore the error and just give up. If we failed to store the
        // error, then the login will just fail with a generic error.
        Log.warn("Error in OAuth Server while storing pending login result.\n" + err.stack || err.message);
      }
    } // close the popup. because nobody likes them just hanging
    // there.  when someone sees this multiple times they might
    // think to check server logs (we hope?)
    // Catch errors because any exception here will crash the runner.


    try {
      OAuth._endOfLoginResponse(res, {
        query: requestData,
        loginStyle: OAuth._loginStyleFromQuery(requestData),
        error: err
      });
    } catch (err) {
      Log.warn("Error generating end of login response\n" + (err && (err.stack || err.message)));
    }
  }
}; // Listen to incoming OAuth http requests


WebApp.connectHandlers.use('/_oauth', bodyParser.json());
WebApp.connectHandlers.use('/_oauth', bodyParser.urlencoded({
  extended: false
}));
WebApp.connectHandlers.use(middleware);
OAuthTest.middleware = middleware; // Handle /_oauth/* paths and extract the service name.
//
// @returns {String|null} e.g. "facebook", or null if this isn't an
// oauth request

const oauthServiceName = req => {
  // req.url will be "/_oauth/<service name>" with an optional "?close".
  const i = req.url.indexOf('?');
  let barePath;
  if (i === -1) barePath = req.url;else barePath = req.url.substring(0, i);
  const splitPath = barePath.split('/'); // Any non-oauth request will continue down the default
  // middlewares.

  if (splitPath[1] !== '_oauth') return null; // Find service based on url

  const serviceName = splitPath[2];
  return serviceName;
}; // Make sure we're configured


const ensureConfigured = serviceName => {
  if (!ServiceConfiguration.configurations.findOne({
    service: serviceName
  })) {
    throw new ServiceConfiguration.ConfigError();
  }
};

const isSafe = value => {
  // This matches strings generated by `Random.secret` and
  // `Random.id`.
  return typeof value === "string" && /^[a-zA-Z0-9\-_]+$/.test(value);
}; // Internal: used by the oauth1 and oauth2 packages


OAuth._renderOauthResults = (res, query, credentialSecret) => {
  // For tests, we support the `only_credential_secret_for_test`
  // parameter, which just returns the credential secret without any
  // surrounding HTML. (The test needs to be able to easily grab the
  // secret and use it to log in.)
  //
  // XXX only_credential_secret_for_test could be useful for other
  // things beside tests, like command-line clients. We should give it a
  // real name and serve the credential secret in JSON.
  if (query.only_credential_secret_for_test) {
    res.writeHead(200, {
      'Content-Type': 'text/html'
    });
    res.end(credentialSecret, 'utf-8');
  } else {
    const details = {
      query,
      loginStyle: OAuth._loginStyleFromQuery(query)
    };

    if (query.error) {
      details.error = query.error;
    } else {
      const token = OAuth._credentialTokenFromQuery(query);

      const secret = credentialSecret;

      if (token && secret && isSafe(token) && isSafe(secret)) {
        details.credentials = {
          token: token,
          secret: secret
        };
      } else {
        details.error = "invalid_credential_token_or_secret";
      }
    }

    OAuth._endOfLoginResponse(res, details);
  }
}; // This "template" (not a real Spacebars template, just an HTML file
// with some ##PLACEHOLDER##s) communicates the credential secret back
// to the main window and then closes the popup.


OAuth._endOfPopupResponseTemplate = Assets.getText("end_of_popup_response.html");
OAuth._endOfRedirectResponseTemplate = Assets.getText("end_of_redirect_response.html"); // Renders the end of login response template into some HTML and JavaScript
// that closes the popup or redirects at the end of the OAuth flow.
//
// options are:
//   - loginStyle ("popup" or "redirect")
//   - setCredentialToken (boolean)
//   - credentialToken
//   - credentialSecret
//   - redirectUrl
//   - isCordova (boolean)
//

const renderEndOfLoginResponse = options => {
  // It would be nice to use Blaze here, but it's a little tricky
  // because our mustaches would be inside a <script> tag, and Blaze
  // would treat the <script> tag contents as text (e.g. encode '&' as
  // '&amp;'). So we just do a simple replace.
  const escape = s => {
    if (s) {
      return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\"/g, "&quot;").replace(/\'/g, "&#x27;").replace(/\//g, "&#x2F;");
    } else {
      return s;
    }
  }; // Escape everything just to be safe (we've already checked that some
  // of this data -- the token and secret -- are safe).


  const config = {
    setCredentialToken: !!options.setCredentialToken,
    credentialToken: escape(options.credentialToken),
    credentialSecret: escape(options.credentialSecret),
    storagePrefix: escape(OAuth._storageTokenPrefix),
    redirectUrl: escape(options.redirectUrl),
    isCordova: !!options.isCordova
  };
  let template;

  if (options.loginStyle === 'popup') {
    template = OAuth._endOfPopupResponseTemplate;
  } else if (options.loginStyle === 'redirect') {
    template = OAuth._endOfRedirectResponseTemplate;
  } else {
    throw new Error("invalid loginStyle: ".concat(options.loginStyle));
  }

  const result = template.replace(/##CONFIG##/, JSON.stringify(config)).replace(/##ROOT_URL_PATH_PREFIX##/, __meteor_runtime_config__.ROOT_URL_PATH_PREFIX);
  return "<!DOCTYPE html>\n".concat(result);
}; // Writes an HTTP response to the popup window at the end of an OAuth
// login flow. At this point, if the user has successfully authenticated
// to the OAuth server and authorized this app, we communicate the
// credentialToken and credentialSecret to the main window. The main
// window must provide both these values to the DDP `login` method to
// authenticate its DDP connection. After communicating these vaues to
// the main window, we close the popup.
//
// We export this function so that developers can override this
// behavior, which is particularly useful in, for example, some mobile
// environments where popups and/or `window.opener` don't work. For
// example, an app could override `OAuth._endOfPopupResponse` to put the
// credential token and credential secret in the popup URL for the main
// window to read them there instead of using `window.opener`. If you
// override this function, you take responsibility for writing to the
// request and calling `res.end()` to complete the request.
//
// Arguments:
//   - res: the HTTP response object
//   - details:
//      - query: the query string on the HTTP request
//      - credentials: { token: *, secret: * }. If present, this field
//        indicates that the login was successful. Return these values
//        to the client, who can use them to log in over DDP. If
//        present, the values have been checked against a limited
//        character set and are safe to include in HTML.
//      - error: if present, a string or Error indicating an error that
//        occurred during the login. This can come from the client and
//        so shouldn't be trusted for security decisions or included in
//        the response without sanitizing it first. Only one of `error`
//        or `credentials` should be set.


OAuth._endOfLoginResponse = (res, details) => {
  res.writeHead(200, {
    'Content-Type': 'text/html'
  });
  let redirectUrl;

  if (details.loginStyle === 'redirect') {
    var _Meteor$settings, _Meteor$settings$pack, _Meteor$settings$pack2;

    redirectUrl = OAuth._stateFromQuery(details.query).redirectUrl;
    const appHost = Meteor.absoluteUrl();

    if (!((_Meteor$settings = Meteor.settings) !== null && _Meteor$settings !== void 0 && (_Meteor$settings$pack = _Meteor$settings.packages) !== null && _Meteor$settings$pack !== void 0 && (_Meteor$settings$pack2 = _Meteor$settings$pack.oauth) !== null && _Meteor$settings$pack2 !== void 0 && _Meteor$settings$pack2.disableCheckRedirectUrlOrigin) && OAuth._checkRedirectUrlOrigin(redirectUrl)) {
      details.error = "redirectUrl (".concat(redirectUrl) + ") is not on the same host as the app (".concat(appHost, ")");
      redirectUrl = appHost;
    }
  }

  const isCordova = OAuth._isCordovaFromQuery(details.query);

  if (details.error) {
    Log.warn("Error in OAuth Server: " + (details.error instanceof Error ? details.error.message : details.error));
    res.end(renderEndOfLoginResponse({
      loginStyle: details.loginStyle,
      setCredentialToken: false,
      redirectUrl,
      isCordova
    }), "utf-8");
    return;
  } // If we have a credentialSecret, report it back to the parent
  // window, with the corresponding credentialToken. The parent window
  // uses the credentialToken and credentialSecret to log in over DDP.


  res.end(renderEndOfLoginResponse({
    loginStyle: details.loginStyle,
    setCredentialToken: true,
    credentialToken: details.credentials.token,
    credentialSecret: details.credentials.secret,
    redirectUrl,
    isCordova
  }), "utf-8");
};

const OAuthEncryption = Package["oauth-encryption"] && Package["oauth-encryption"].OAuthEncryption;

const usingOAuthEncryption = () => OAuthEncryption && OAuthEncryption.keyIsLoaded(); // Encrypt sensitive service data such as access tokens if the
// "oauth-encryption" package is loaded and the oauth secret key has
// been specified.  Returns the unencrypted plaintext otherwise.
//
// The user id is not specified because the user isn't known yet at
// this point in the oauth authentication process.  After the oauth
// authentication process completes the encrypted service data fields
// will be re-encrypted with the user id included before inserting the
// service data into the user document.
//


OAuth.sealSecret = plaintext => {
  if (usingOAuthEncryption()) return OAuthEncryption.seal(plaintext);else return plaintext;
}; // Unencrypt a service data field, if the "oauth-encryption"
// package is loaded and the field is encrypted.
//
// Throws an error if the "oauth-encryption" package is loaded and the
// field is encrypted, but the oauth secret key hasn't been specified.
//


OAuth.openSecret = (maybeSecret, userId) => {
  if (!Package["oauth-encryption"] || !OAuthEncryption.isSealed(maybeSecret)) return maybeSecret;
  return OAuthEncryption.open(maybeSecret, userId);
}; // Unencrypt fields in the service data object.
//


OAuth.openSecrets = (serviceData, userId) => {
  const result = {};
  Object.keys(serviceData).forEach(key => result[key] = OAuth.openSecret(serviceData[key], userId));
  return result;
};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"pending_credentials.js":function module(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/oauth/pending_credentials.js                                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
//
// When an oauth request is made, Meteor receives oauth credentials
// in one browser tab, and temporarily persists them while that
// tab is closed, then retrieves them in the browser tab that
// initiated the credential request.
//
// _pendingCredentials is the storage mechanism used to share the
// credential between the 2 tabs
//
// Collection containing pending credentials of oauth credential requests
// Has key, credential, and createdAt fields.
OAuth._pendingCredentials = new Mongo.Collection("meteor_oauth_pendingCredentials", {
  _preventAutopublish: true
});

OAuth._pendingCredentials.createIndex('key', {
  unique: true
});

OAuth._pendingCredentials.createIndex('credentialSecret');

OAuth._pendingCredentials.createIndex('createdAt'); // Periodically clear old entries that were never retrieved


const _cleanStaleResults = () => {
  // Remove credentials older than 1 minute
  const timeCutoff = new Date();
  timeCutoff.setMinutes(timeCutoff.getMinutes() - 1);

  OAuth._pendingCredentials.remove({
    createdAt: {
      $lt: timeCutoff
    }
  });
};

const _cleanupHandle = Meteor.setInterval(_cleanStaleResults, 60 * 1000); // Stores the key and credential in the _pendingCredentials collection.
// Will throw an exception if `key` is not a string.
//
// @param key {string}
// @param credential {Object}   The credential to store
// @param credentialSecret {string} A secret that must be presented in
//   addition to the `key` to retrieve the credential
//


OAuth._storePendingCredential = function (key, credential) {
  let credentialSecret = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;
  check(key, String);
  check(credentialSecret, Match.Maybe(String));

  if (credential instanceof Error) {
    credential = storableError(credential);
  } else {
    credential = OAuth.sealSecret(credential);
  } // We do an upsert here instead of an insert in case the user happens
  // to somehow send the same `state` parameter twice during an OAuth
  // login; we don't want a duplicate key error.


  OAuth._pendingCredentials.upsert({
    key
  }, {
    key,
    credential,
    credentialSecret,
    createdAt: new Date()
  });
}; // Retrieves and removes a credential from the _pendingCredentials collection
//
// @param key {string}
// @param credentialSecret {string}
//


OAuth._retrievePendingCredential = function (key) {
  let credentialSecret = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
  check(key, String);

  const pendingCredential = OAuth._pendingCredentials.findOne({
    key,
    credentialSecret
  });

  if (pendingCredential) {
    OAuth._pendingCredentials.remove({
      _id: pendingCredential._id
    });

    if (pendingCredential.credential.error) return recreateError(pendingCredential.credential.error);else return OAuth.openSecret(pendingCredential.credential);
  } else {
    return undefined;
  }
}; // Convert an Error into an object that can be stored in mongo
// Note: A Meteor.Error is reconstructed as a Meteor.Error
// All other error classes are reconstructed as a plain Error.
// TODO: Can we do this more simply with EJSON?


const storableError = error => {
  const plainObject = {};
  Object.getOwnPropertyNames(error).forEach(key => plainObject[key] = error[key]); // Keep track of whether it's a Meteor.Error

  if (error instanceof Meteor.Error) {
    plainObject['meteorError'] = true;
  }

  return {
    error: plainObject
  };
}; // Create an error from the error format stored in mongo


const recreateError = errorDoc => {
  let error;

  if (errorDoc.meteorError) {
    error = new Meteor.Error();
    delete errorDoc.meteorError;
  } else {
    error = new Error();
  }

  Object.getOwnPropertyNames(errorDoc).forEach(key => error[key] = errorDoc[key]);
  return error;
};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"oauth_common.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/oauth/oauth_common.js                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }

}, 0);
OAuth._storageTokenPrefix = "Meteor.oauth.credentialSecret-";

OAuth._redirectUri = (serviceName, config, params, absoluteUrlOptions) => {
  // Clone because we're going to mutate 'params'. The 'cordova' and
  // 'android' parameters are only used for picking the host of the
  // redirect URL, and not actually included in the redirect URL itself.
  let isCordova = false;
  let isAndroid = false;

  if (params) {
    params = _objectSpread({}, params);
    isCordova = params.cordova;
    isAndroid = params.android;
    delete params.cordova;
    delete params.android;

    if (Object.keys(params).length === 0) {
      params = undefined;
    }
  }

  if (Meteor.isServer && isCordova) {
    const url = Npm.require('url');

    let rootUrl = process.env.MOBILE_ROOT_URL || __meteor_runtime_config__.ROOT_URL;

    if (isAndroid) {
      // Match the replace that we do in cordova boilerplate
      // (boilerplate-generator package).
      // XXX Maybe we should put this in a separate package or something
      // that is used here and by boilerplate-generator? Or maybe
      // `Meteor.absoluteUrl` should know how to do this?
      const parsedRootUrl = url.parse(rootUrl);

      if (parsedRootUrl.hostname === "localhost") {
        parsedRootUrl.hostname = "10.0.2.2";
        delete parsedRootUrl.host;
      }

      rootUrl = url.format(parsedRootUrl);
    }

    absoluteUrlOptions = _objectSpread(_objectSpread({}, absoluteUrlOptions), {}, {
      // For Cordova clients, redirect to the special Cordova root url
      // (likely a local IP in development mode).
      rootUrl
    });
  }

  return URL._constructUrl(Meteor.absoluteUrl("_oauth/".concat(serviceName), absoluteUrlOptions), null, params);
};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"node_modules":{"body-parser":{"package.json":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// node_modules/meteor/oauth/node_modules/body-parser/package.json                                                  //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.exports = {
  "name": "body-parser",
  "version": "1.19.0"
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// node_modules/meteor/oauth/node_modules/body-parser/index.js                                                      //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.useNode();
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

require("/node_modules/meteor/oauth/oauth_server.js");
require("/node_modules/meteor/oauth/pending_credentials.js");
require("/node_modules/meteor/oauth/oauth_common.js");

/* Exports */
Package._define("oauth", {
  OAuth: OAuth,
  OAuthTest: OAuthTest
});

})();

//# sourceURL=meteor://💻app/packages/oauth.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb2F1dGgvb2F1dGhfc2VydmVyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9vYXV0aC9wZW5kaW5nX2NyZWRlbnRpYWxzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9vYXV0aC9vYXV0aF9jb21tb24uanMiXSwibmFtZXMiOlsiYm9keVBhcnNlciIsIm1vZHVsZSIsImxpbmsiLCJkZWZhdWx0IiwidiIsIk9BdXRoIiwiT0F1dGhUZXN0IiwiUm91dGVQb2xpY3kiLCJkZWNsYXJlIiwicmVnaXN0ZXJlZFNlcnZpY2VzIiwiX3JlcXVlc3RIYW5kbGVycyIsInJlZ2lzdGVyU2VydmljZSIsIm5hbWUiLCJ2ZXJzaW9uIiwidXJscyIsImhhbmRsZU9hdXRoUmVxdWVzdCIsIkVycm9yIiwic2VydmljZU5hbWUiLCJ1bnJlZ2lzdGVyU2VydmljZSIsInJldHJpZXZlQ3JlZGVudGlhbCIsImNyZWRlbnRpYWxUb2tlbiIsImNyZWRlbnRpYWxTZWNyZXQiLCJfcmV0cmlldmVQZW5kaW5nQ3JlZGVudGlhbCIsIl9nZW5lcmF0ZVN0YXRlIiwibG9naW5TdHlsZSIsInJlZGlyZWN0VXJsIiwiQnVmZmVyIiwiZnJvbSIsIkpTT04iLCJzdHJpbmdpZnkiLCJ0b1N0cmluZyIsIl9zdGF0ZUZyb21RdWVyeSIsInF1ZXJ5Iiwic3RyaW5nIiwic3RhdGUiLCJlIiwiTG9nIiwid2FybiIsInBhcnNlIiwiX2xvZ2luU3R5bGVGcm9tUXVlcnkiLCJzdHlsZSIsImVyciIsIl9jcmVkZW50aWFsVG9rZW5Gcm9tUXVlcnkiLCJfaXNDb3Jkb3ZhRnJvbVF1ZXJ5IiwiaXNDb3Jkb3ZhIiwiX2NoZWNrUmVkaXJlY3RVcmxPcmlnaW4iLCJhcHBIb3N0IiwiTWV0ZW9yIiwiYWJzb2x1dGVVcmwiLCJhcHBIb3N0UmVwbGFjZWRMb2NhbGhvc3QiLCJ1bmRlZmluZWQiLCJyZXBsYWNlTG9jYWxob3N0Iiwic3Vic3RyIiwibGVuZ3RoIiwibWlkZGxld2FyZSIsInJlcSIsInJlcyIsIm5leHQiLCJyZXF1ZXN0RGF0YSIsIm9hdXRoU2VydmljZU5hbWUiLCJzZXJ2aWNlIiwiZW5zdXJlQ29uZmlndXJlZCIsImhhbmRsZXIiLCJtZXRob2QiLCJib2R5IiwiX3N0b3JlUGVuZGluZ0NyZWRlbnRpYWwiLCJzdGFjayIsIm1lc3NhZ2UiLCJfZW5kT2ZMb2dpblJlc3BvbnNlIiwiZXJyb3IiLCJXZWJBcHAiLCJjb25uZWN0SGFuZGxlcnMiLCJ1c2UiLCJqc29uIiwidXJsZW5jb2RlZCIsImV4dGVuZGVkIiwiaSIsInVybCIsImluZGV4T2YiLCJiYXJlUGF0aCIsInN1YnN0cmluZyIsInNwbGl0UGF0aCIsInNwbGl0IiwiU2VydmljZUNvbmZpZ3VyYXRpb24iLCJjb25maWd1cmF0aW9ucyIsImZpbmRPbmUiLCJDb25maWdFcnJvciIsImlzU2FmZSIsInZhbHVlIiwidGVzdCIsIl9yZW5kZXJPYXV0aFJlc3VsdHMiLCJvbmx5X2NyZWRlbnRpYWxfc2VjcmV0X2Zvcl90ZXN0Iiwid3JpdGVIZWFkIiwiZW5kIiwiZGV0YWlscyIsInRva2VuIiwic2VjcmV0IiwiY3JlZGVudGlhbHMiLCJfZW5kT2ZQb3B1cFJlc3BvbnNlVGVtcGxhdGUiLCJBc3NldHMiLCJnZXRUZXh0IiwiX2VuZE9mUmVkaXJlY3RSZXNwb25zZVRlbXBsYXRlIiwicmVuZGVyRW5kT2ZMb2dpblJlc3BvbnNlIiwib3B0aW9ucyIsImVzY2FwZSIsInMiLCJyZXBsYWNlIiwiY29uZmlnIiwic2V0Q3JlZGVudGlhbFRva2VuIiwic3RvcmFnZVByZWZpeCIsIl9zdG9yYWdlVG9rZW5QcmVmaXgiLCJ0ZW1wbGF0ZSIsInJlc3VsdCIsIl9fbWV0ZW9yX3J1bnRpbWVfY29uZmlnX18iLCJST09UX1VSTF9QQVRIX1BSRUZJWCIsInNldHRpbmdzIiwicGFja2FnZXMiLCJvYXV0aCIsImRpc2FibGVDaGVja1JlZGlyZWN0VXJsT3JpZ2luIiwiT0F1dGhFbmNyeXB0aW9uIiwiUGFja2FnZSIsInVzaW5nT0F1dGhFbmNyeXB0aW9uIiwia2V5SXNMb2FkZWQiLCJzZWFsU2VjcmV0IiwicGxhaW50ZXh0Iiwic2VhbCIsIm9wZW5TZWNyZXQiLCJtYXliZVNlY3JldCIsInVzZXJJZCIsImlzU2VhbGVkIiwib3BlbiIsIm9wZW5TZWNyZXRzIiwic2VydmljZURhdGEiLCJPYmplY3QiLCJrZXlzIiwiZm9yRWFjaCIsImtleSIsIl9wZW5kaW5nQ3JlZGVudGlhbHMiLCJNb25nbyIsIkNvbGxlY3Rpb24iLCJfcHJldmVudEF1dG9wdWJsaXNoIiwiY3JlYXRlSW5kZXgiLCJ1bmlxdWUiLCJfY2xlYW5TdGFsZVJlc3VsdHMiLCJ0aW1lQ3V0b2ZmIiwiRGF0ZSIsInNldE1pbnV0ZXMiLCJnZXRNaW51dGVzIiwicmVtb3ZlIiwiY3JlYXRlZEF0IiwiJGx0IiwiX2NsZWFudXBIYW5kbGUiLCJzZXRJbnRlcnZhbCIsImNyZWRlbnRpYWwiLCJjaGVjayIsIlN0cmluZyIsIk1hdGNoIiwiTWF5YmUiLCJzdG9yYWJsZUVycm9yIiwidXBzZXJ0IiwicGVuZGluZ0NyZWRlbnRpYWwiLCJfaWQiLCJyZWNyZWF0ZUVycm9yIiwicGxhaW5PYmplY3QiLCJnZXRPd25Qcm9wZXJ0eU5hbWVzIiwiZXJyb3JEb2MiLCJtZXRlb3JFcnJvciIsIl9vYmplY3RTcHJlYWQiLCJfcmVkaXJlY3RVcmkiLCJwYXJhbXMiLCJhYnNvbHV0ZVVybE9wdGlvbnMiLCJpc0FuZHJvaWQiLCJjb3Jkb3ZhIiwiYW5kcm9pZCIsImlzU2VydmVyIiwiTnBtIiwicmVxdWlyZSIsInJvb3RVcmwiLCJwcm9jZXNzIiwiZW52IiwiTU9CSUxFX1JPT1RfVVJMIiwiUk9PVF9VUkwiLCJwYXJzZWRSb290VXJsIiwiaG9zdG5hbWUiLCJob3N0IiwiZm9ybWF0IiwiVVJMIiwiX2NvbnN0cnVjdFVybCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBSUEsVUFBSjtBQUFlQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUNKLGNBQVUsR0FBQ0ksQ0FBWDtBQUFhOztBQUF6QixDQUExQixFQUFxRCxDQUFyRDtBQUVmQyxLQUFLLEdBQUcsRUFBUjtBQUNBQyxTQUFTLEdBQUcsRUFBWjtBQUVBQyxXQUFXLENBQUNDLE9BQVosQ0FBb0IsVUFBcEIsRUFBZ0MsU0FBaEM7QUFFQSxNQUFNQyxrQkFBa0IsR0FBRyxFQUEzQixDLENBRUE7QUFDQTtBQUNBOztBQUNBSixLQUFLLENBQUNLLGdCQUFOLEdBQXlCLEVBQXpCLEMsQ0FHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQUwsS0FBSyxDQUFDTSxlQUFOLEdBQXdCLENBQUNDLElBQUQsRUFBT0MsT0FBUCxFQUFnQkMsSUFBaEIsRUFBc0JDLGtCQUF0QixLQUE2QztBQUNuRSxNQUFJTixrQkFBa0IsQ0FBQ0csSUFBRCxDQUF0QixFQUNFLE1BQU0sSUFBSUksS0FBSixrQ0FBb0NKLElBQXBDLG9CQUFOO0FBRUZILG9CQUFrQixDQUFDRyxJQUFELENBQWxCLEdBQTJCO0FBQ3pCSyxlQUFXLEVBQUVMLElBRFk7QUFFekJDLFdBRnlCO0FBR3pCQyxRQUh5QjtBQUl6QkM7QUFKeUIsR0FBM0I7QUFNRCxDQVZELEMsQ0FZQTs7O0FBQ0FULFNBQVMsQ0FBQ1ksaUJBQVYsR0FBOEJOLElBQUksSUFBSTtBQUNwQyxTQUFPSCxrQkFBa0IsQ0FBQ0csSUFBRCxDQUF6QjtBQUNELENBRkQ7O0FBS0FQLEtBQUssQ0FBQ2Msa0JBQU4sR0FBMkIsQ0FBQ0MsZUFBRCxFQUFrQkMsZ0JBQWxCLEtBQ3pCaEIsS0FBSyxDQUFDaUIsMEJBQU4sQ0FBaUNGLGVBQWpDLEVBQWtEQyxnQkFBbEQsQ0FERixDLENBSUE7QUFDQTtBQUNBOzs7QUFDQWhCLEtBQUssQ0FBQ2tCLGNBQU4sR0FBdUIsQ0FBQ0MsVUFBRCxFQUFhSixlQUFiLEVBQThCSyxXQUE5QixLQUE4QztBQUNuRSxTQUFPQyxNQUFNLENBQUNDLElBQVAsQ0FBWUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDaENMLGNBQVUsRUFBRUEsVUFEb0I7QUFFaENKLG1CQUFlLEVBQUVBLGVBRmU7QUFHaENLLGVBQVcsRUFBRUE7QUFIbUIsR0FBZixDQUFaLEVBR3VCSyxRQUh2QixDQUdnQyxRQUhoQyxDQUFQO0FBSUQsQ0FMRDs7QUFPQXpCLEtBQUssQ0FBQzBCLGVBQU4sR0FBd0JDLEtBQUssSUFBSTtBQUMvQixNQUFJQyxNQUFKOztBQUNBLE1BQUk7QUFDRkEsVUFBTSxHQUFHUCxNQUFNLENBQUNDLElBQVAsQ0FBWUssS0FBSyxDQUFDRSxLQUFsQixFQUF5QixRQUF6QixFQUFtQ0osUUFBbkMsQ0FBNEMsUUFBNUMsQ0FBVDtBQUNELEdBRkQsQ0FFRSxPQUFPSyxDQUFQLEVBQVU7QUFDVkMsT0FBRyxDQUFDQyxJQUFKLDJEQUE0REwsS0FBSyxDQUFDRSxLQUFsRTtBQUNBLFVBQU1DLENBQU47QUFDRDs7QUFFRCxNQUFJO0FBQ0YsV0FBT1AsSUFBSSxDQUFDVSxLQUFMLENBQVdMLE1BQVgsQ0FBUDtBQUNELEdBRkQsQ0FFRSxPQUFPRSxDQUFQLEVBQVU7QUFDVkMsT0FBRyxDQUFDQyxJQUFKLG1EQUFvREosTUFBcEQ7QUFDQSxVQUFNRSxDQUFOO0FBQ0Q7QUFDRixDQWZEOztBQWlCQTlCLEtBQUssQ0FBQ2tDLG9CQUFOLEdBQTZCUCxLQUFLLElBQUk7QUFDcEMsTUFBSVEsS0FBSixDQURvQyxDQUVwQztBQUNBO0FBQ0E7O0FBQ0EsTUFBSTtBQUNGQSxTQUFLLEdBQUduQyxLQUFLLENBQUMwQixlQUFOLENBQXNCQyxLQUF0QixFQUE2QlIsVUFBckM7QUFDRCxHQUZELENBRUUsT0FBT2lCLEdBQVAsRUFBWTtBQUNaRCxTQUFLLEdBQUcsT0FBUjtBQUNEOztBQUNELE1BQUlBLEtBQUssS0FBSyxPQUFWLElBQXFCQSxLQUFLLEtBQUssVUFBbkMsRUFBK0M7QUFDN0MsVUFBTSxJQUFJeEIsS0FBSixxQ0FBdUN3QixLQUF2QyxFQUFOO0FBQ0Q7O0FBQ0QsU0FBT0EsS0FBUDtBQUNELENBZEQ7O0FBZ0JBbkMsS0FBSyxDQUFDcUMseUJBQU4sR0FBa0NWLEtBQUssSUFBSTtBQUN6QyxNQUFJRSxLQUFKLENBRHlDLENBRXpDO0FBQ0E7QUFDQTtBQUNBOztBQUNBLE1BQUk7QUFDRkEsU0FBSyxHQUFHN0IsS0FBSyxDQUFDMEIsZUFBTixDQUFzQkMsS0FBdEIsQ0FBUjtBQUNELEdBRkQsQ0FFRSxPQUFPUyxHQUFQLEVBQVk7QUFDWixXQUFPVCxLQUFLLENBQUNFLEtBQWI7QUFDRDs7QUFDRCxTQUFPQSxLQUFLLENBQUNkLGVBQWI7QUFDRCxDQVpEOztBQWNBZixLQUFLLENBQUNzQyxtQkFBTixHQUE0QlgsS0FBSyxJQUFJO0FBQ25DLE1BQUk7QUFDRixXQUFPLENBQUMsQ0FBRTNCLEtBQUssQ0FBQzBCLGVBQU4sQ0FBc0JDLEtBQXRCLEVBQTZCWSxTQUF2QztBQUNELEdBRkQsQ0FFRSxPQUFPSCxHQUFQLEVBQVk7QUFDWjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQU8sS0FBUDtBQUNEO0FBQ0YsQ0FWRCxDLENBWUE7QUFDQTtBQUNBO0FBQ0E7OztBQUNBcEMsS0FBSyxDQUFDd0MsdUJBQU4sR0FBZ0NwQixXQUFXLElBQUk7QUFDN0MsUUFBTXFCLE9BQU8sR0FBR0MsTUFBTSxDQUFDQyxXQUFQLEVBQWhCO0FBQ0EsUUFBTUMsd0JBQXdCLEdBQUdGLE1BQU0sQ0FBQ0MsV0FBUCxDQUFtQkUsU0FBbkIsRUFBOEI7QUFDN0RDLG9CQUFnQixFQUFFO0FBRDJDLEdBQTlCLENBQWpDO0FBR0EsU0FDRTFCLFdBQVcsQ0FBQzJCLE1BQVosQ0FBbUIsQ0FBbkIsRUFBc0JOLE9BQU8sQ0FBQ08sTUFBOUIsTUFBMENQLE9BQTFDLElBQ0FyQixXQUFXLENBQUMyQixNQUFaLENBQW1CLENBQW5CLEVBQXNCSCx3QkFBd0IsQ0FBQ0ksTUFBL0MsTUFBMkRKLHdCQUY3RDtBQUlELENBVEQ7O0FBV0EsTUFBTUssVUFBVSxHQUFHLENBQUNDLEdBQUQsRUFBTUMsR0FBTixFQUFXQyxJQUFYLEtBQW9CO0FBQ3JDLE1BQUlDLFdBQUosQ0FEcUMsQ0FHckM7QUFDQTs7QUFDQSxNQUFJO0FBQ0YsVUFBTXpDLFdBQVcsR0FBRzBDLGdCQUFnQixDQUFDSixHQUFELENBQXBDOztBQUNBLFFBQUksQ0FBQ3RDLFdBQUwsRUFBa0I7QUFDaEI7QUFDQXdDLFVBQUk7QUFDSjtBQUNEOztBQUVELFVBQU1HLE9BQU8sR0FBR25ELGtCQUFrQixDQUFDUSxXQUFELENBQWxDLENBUkUsQ0FVRjs7QUFDQSxRQUFJLENBQUMyQyxPQUFMLEVBQ0UsTUFBTSxJQUFJNUMsS0FBSixvQ0FBc0NDLFdBQXRDLEVBQU4sQ0FaQSxDQWNGOztBQUNBNEMsb0JBQWdCLENBQUM1QyxXQUFELENBQWhCO0FBRUEsVUFBTTZDLE9BQU8sR0FBR3pELEtBQUssQ0FBQ0ssZ0JBQU4sQ0FBdUJrRCxPQUFPLENBQUMvQyxPQUEvQixDQUFoQjtBQUNBLFFBQUksQ0FBQ2lELE9BQUwsRUFDRSxNQUFNLElBQUk5QyxLQUFKLG9DQUFzQzRDLE9BQU8sQ0FBQy9DLE9BQTlDLEVBQU47O0FBRUYsUUFBSTBDLEdBQUcsQ0FBQ1EsTUFBSixLQUFlLEtBQW5CLEVBQTBCO0FBQ3hCTCxpQkFBVyxHQUFHSCxHQUFHLENBQUN2QixLQUFsQjtBQUNELEtBRkQsTUFFTztBQUNMMEIsaUJBQVcsR0FBR0gsR0FBRyxDQUFDUyxJQUFsQjtBQUNEOztBQUVERixXQUFPLENBQUNGLE9BQUQsRUFBVUYsV0FBVixFQUF1QkYsR0FBdkIsQ0FBUDtBQUNELEdBNUJELENBNEJFLE9BQU9mLEdBQVAsRUFBWTtBQUFBOztBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBSSxnQkFBQWlCLFdBQVcsVUFBWCw0Q0FBYXhCLEtBQWIsSUFBc0JPLEdBQUcsWUFBWXpCLEtBQXpDLEVBQWdEO0FBQzlDLFVBQUk7QUFBRTtBQUNKWCxhQUFLLENBQUM0RCx1QkFBTixDQUE4QjVELEtBQUssQ0FBQ3FDLHlCQUFOLENBQWdDZ0IsV0FBaEMsQ0FBOUIsRUFBNEVqQixHQUE1RTtBQUNELE9BRkQsQ0FFRSxPQUFPQSxHQUFQLEVBQVk7QUFDWjtBQUNBO0FBQ0FMLFdBQUcsQ0FBQ0MsSUFBSixDQUFTLGdFQUNBSSxHQUFHLENBQUN5QixLQURKLElBQ2F6QixHQUFHLENBQUMwQixPQUQxQjtBQUVEO0FBQ0YsS0FqQlcsQ0FtQlo7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLFFBQUk7QUFDRjlELFdBQUssQ0FBQytELG1CQUFOLENBQTBCWixHQUExQixFQUErQjtBQUM3QnhCLGFBQUssRUFBRTBCLFdBRHNCO0FBRTdCbEMsa0JBQVUsRUFBRW5CLEtBQUssQ0FBQ2tDLG9CQUFOLENBQTJCbUIsV0FBM0IsQ0FGaUI7QUFHN0JXLGFBQUssRUFBRTVCO0FBSHNCLE9BQS9CO0FBS0QsS0FORCxDQU1FLE9BQU9BLEdBQVAsRUFBWTtBQUNaTCxTQUFHLENBQUNDLElBQUosQ0FBUyw4Q0FDQ0ksR0FBRyxLQUFLQSxHQUFHLENBQUN5QixLQUFKLElBQWF6QixHQUFHLENBQUMwQixPQUF0QixDQURKLENBQVQ7QUFFRDtBQUNGO0FBQ0YsQ0FuRUQsQyxDQXFFQTs7O0FBQ0FHLE1BQU0sQ0FBQ0MsZUFBUCxDQUF1QkMsR0FBdkIsQ0FBMkIsU0FBM0IsRUFBc0N4RSxVQUFVLENBQUN5RSxJQUFYLEVBQXRDO0FBQ0FILE1BQU0sQ0FBQ0MsZUFBUCxDQUF1QkMsR0FBdkIsQ0FBMkIsU0FBM0IsRUFBc0N4RSxVQUFVLENBQUMwRSxVQUFYLENBQXNCO0FBQUVDLFVBQVEsRUFBRTtBQUFaLENBQXRCLENBQXRDO0FBQ0FMLE1BQU0sQ0FBQ0MsZUFBUCxDQUF1QkMsR0FBdkIsQ0FBMkJsQixVQUEzQjtBQUVBaEQsU0FBUyxDQUFDZ0QsVUFBVixHQUF1QkEsVUFBdkIsQyxDQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLE1BQU1LLGdCQUFnQixHQUFHSixHQUFHLElBQUk7QUFDOUI7QUFDQSxRQUFNcUIsQ0FBQyxHQUFHckIsR0FBRyxDQUFDc0IsR0FBSixDQUFRQyxPQUFSLENBQWdCLEdBQWhCLENBQVY7QUFDQSxNQUFJQyxRQUFKO0FBQ0EsTUFBSUgsQ0FBQyxLQUFLLENBQUMsQ0FBWCxFQUNFRyxRQUFRLEdBQUd4QixHQUFHLENBQUNzQixHQUFmLENBREYsS0FHRUUsUUFBUSxHQUFHeEIsR0FBRyxDQUFDc0IsR0FBSixDQUFRRyxTQUFSLENBQWtCLENBQWxCLEVBQXFCSixDQUFyQixDQUFYO0FBQ0YsUUFBTUssU0FBUyxHQUFHRixRQUFRLENBQUNHLEtBQVQsQ0FBZSxHQUFmLENBQWxCLENBUjhCLENBVTlCO0FBQ0E7O0FBQ0EsTUFBSUQsU0FBUyxDQUFDLENBQUQsQ0FBVCxLQUFpQixRQUFyQixFQUNFLE9BQU8sSUFBUCxDQWI0QixDQWU5Qjs7QUFDQSxRQUFNaEUsV0FBVyxHQUFHZ0UsU0FBUyxDQUFDLENBQUQsQ0FBN0I7QUFDQSxTQUFPaEUsV0FBUDtBQUNELENBbEJELEMsQ0FvQkE7OztBQUNBLE1BQU00QyxnQkFBZ0IsR0FBRzVDLFdBQVcsSUFBSTtBQUN0QyxNQUFJLENBQUNrRSxvQkFBb0IsQ0FBQ0MsY0FBckIsQ0FBb0NDLE9BQXBDLENBQTRDO0FBQUN6QixXQUFPLEVBQUUzQztBQUFWLEdBQTVDLENBQUwsRUFBMEU7QUFDeEUsVUFBTSxJQUFJa0Usb0JBQW9CLENBQUNHLFdBQXpCLEVBQU47QUFDRDtBQUNGLENBSkQ7O0FBTUEsTUFBTUMsTUFBTSxHQUFHQyxLQUFLLElBQUk7QUFDdEI7QUFDQTtBQUNBLFNBQU8sT0FBT0EsS0FBUCxLQUFpQixRQUFqQixJQUNMLG9CQUFvQkMsSUFBcEIsQ0FBeUJELEtBQXpCLENBREY7QUFFRCxDQUxELEMsQ0FPQTs7O0FBQ0FuRixLQUFLLENBQUNxRixtQkFBTixHQUE0QixDQUFDbEMsR0FBRCxFQUFNeEIsS0FBTixFQUFhWCxnQkFBYixLQUFrQztBQUM1RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUEsTUFBSVcsS0FBSyxDQUFDMkQsK0JBQVYsRUFBMkM7QUFDekNuQyxPQUFHLENBQUNvQyxTQUFKLENBQWMsR0FBZCxFQUFtQjtBQUFDLHNCQUFnQjtBQUFqQixLQUFuQjtBQUNBcEMsT0FBRyxDQUFDcUMsR0FBSixDQUFReEUsZ0JBQVIsRUFBMEIsT0FBMUI7QUFDRCxHQUhELE1BR087QUFDTCxVQUFNeUUsT0FBTyxHQUFHO0FBQ2Q5RCxXQURjO0FBRWRSLGdCQUFVLEVBQUVuQixLQUFLLENBQUNrQyxvQkFBTixDQUEyQlAsS0FBM0I7QUFGRSxLQUFoQjs7QUFJQSxRQUFJQSxLQUFLLENBQUNxQyxLQUFWLEVBQWlCO0FBQ2Z5QixhQUFPLENBQUN6QixLQUFSLEdBQWdCckMsS0FBSyxDQUFDcUMsS0FBdEI7QUFDRCxLQUZELE1BRU87QUFDTCxZQUFNMEIsS0FBSyxHQUFHMUYsS0FBSyxDQUFDcUMseUJBQU4sQ0FBZ0NWLEtBQWhDLENBQWQ7O0FBQ0EsWUFBTWdFLE1BQU0sR0FBRzNFLGdCQUFmOztBQUNBLFVBQUkwRSxLQUFLLElBQUlDLE1BQVQsSUFDQVQsTUFBTSxDQUFDUSxLQUFELENBRE4sSUFDaUJSLE1BQU0sQ0FBQ1MsTUFBRCxDQUQzQixFQUNxQztBQUNuQ0YsZUFBTyxDQUFDRyxXQUFSLEdBQXNCO0FBQUVGLGVBQUssRUFBRUEsS0FBVDtBQUFnQkMsZ0JBQU0sRUFBRUE7QUFBeEIsU0FBdEI7QUFDRCxPQUhELE1BR087QUFDTEYsZUFBTyxDQUFDekIsS0FBUixHQUFnQixvQ0FBaEI7QUFDRDtBQUNGOztBQUVEaEUsU0FBSyxDQUFDK0QsbUJBQU4sQ0FBMEJaLEdBQTFCLEVBQStCc0MsT0FBL0I7QUFDRDtBQUNGLENBakNELEMsQ0FtQ0E7QUFDQTtBQUNBOzs7QUFDQXpGLEtBQUssQ0FBQzZGLDJCQUFOLEdBQW9DQyxNQUFNLENBQUNDLE9BQVAsQ0FDbEMsNEJBRGtDLENBQXBDO0FBR0EvRixLQUFLLENBQUNnRyw4QkFBTixHQUF1Q0YsTUFBTSxDQUFDQyxPQUFQLENBQ3JDLCtCQURxQyxDQUF2QyxDLENBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxNQUFNRSx3QkFBd0IsR0FBR0MsT0FBTyxJQUFJO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBRUEsUUFBTUMsTUFBTSxHQUFHQyxDQUFDLElBQUk7QUFDbEIsUUFBSUEsQ0FBSixFQUFPO0FBQ0wsYUFBT0EsQ0FBQyxDQUFDQyxPQUFGLENBQVUsSUFBVixFQUFnQixPQUFoQixFQUNMQSxPQURLLENBQ0csSUFESCxFQUNTLE1BRFQsRUFFTEEsT0FGSyxDQUVHLElBRkgsRUFFUyxNQUZULEVBR0xBLE9BSEssQ0FHRyxLQUhILEVBR1UsUUFIVixFQUlMQSxPQUpLLENBSUcsS0FKSCxFQUlVLFFBSlYsRUFLTEEsT0FMSyxDQUtHLEtBTEgsRUFLVSxRQUxWLENBQVA7QUFNRCxLQVBELE1BT087QUFDTCxhQUFPRCxDQUFQO0FBQ0Q7QUFDRixHQVhELENBTjBDLENBbUIxQztBQUNBOzs7QUFDQSxRQUFNRSxNQUFNLEdBQUc7QUFDYkMsc0JBQWtCLEVBQUUsQ0FBQyxDQUFFTCxPQUFPLENBQUNLLGtCQURsQjtBQUVieEYsbUJBQWUsRUFBRW9GLE1BQU0sQ0FBQ0QsT0FBTyxDQUFDbkYsZUFBVCxDQUZWO0FBR2JDLG9CQUFnQixFQUFFbUYsTUFBTSxDQUFDRCxPQUFPLENBQUNsRixnQkFBVCxDQUhYO0FBSWJ3RixpQkFBYSxFQUFFTCxNQUFNLENBQUNuRyxLQUFLLENBQUN5RyxtQkFBUCxDQUpSO0FBS2JyRixlQUFXLEVBQUUrRSxNQUFNLENBQUNELE9BQU8sQ0FBQzlFLFdBQVQsQ0FMTjtBQU1ibUIsYUFBUyxFQUFFLENBQUMsQ0FBRTJELE9BQU8sQ0FBQzNEO0FBTlQsR0FBZjtBQVNBLE1BQUltRSxRQUFKOztBQUNBLE1BQUlSLE9BQU8sQ0FBQy9FLFVBQVIsS0FBdUIsT0FBM0IsRUFBb0M7QUFDbEN1RixZQUFRLEdBQUcxRyxLQUFLLENBQUM2RiwyQkFBakI7QUFDRCxHQUZELE1BRU8sSUFBSUssT0FBTyxDQUFDL0UsVUFBUixLQUF1QixVQUEzQixFQUF1QztBQUM1Q3VGLFlBQVEsR0FBRzFHLEtBQUssQ0FBQ2dHLDhCQUFqQjtBQUNELEdBRk0sTUFFQTtBQUNMLFVBQU0sSUFBSXJGLEtBQUosK0JBQWlDdUYsT0FBTyxDQUFDL0UsVUFBekMsRUFBTjtBQUNEOztBQUVELFFBQU13RixNQUFNLEdBQUdELFFBQVEsQ0FBQ0wsT0FBVCxDQUFpQixZQUFqQixFQUErQjlFLElBQUksQ0FBQ0MsU0FBTCxDQUFlOEUsTUFBZixDQUEvQixFQUNaRCxPQURZLENBRVgsMEJBRlcsRUFFaUJPLHlCQUF5QixDQUFDQyxvQkFGM0MsQ0FBZjtBQUtBLG9DQUEyQkYsTUFBM0I7QUFDRCxDQTdDRCxDLENBK0NBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTNHLEtBQUssQ0FBQytELG1CQUFOLEdBQTRCLENBQUNaLEdBQUQsRUFBTXNDLE9BQU4sS0FBa0I7QUFDNUN0QyxLQUFHLENBQUNvQyxTQUFKLENBQWMsR0FBZCxFQUFtQjtBQUFDLG9CQUFnQjtBQUFqQixHQUFuQjtBQUVBLE1BQUluRSxXQUFKOztBQUNBLE1BQUlxRSxPQUFPLENBQUN0RSxVQUFSLEtBQXVCLFVBQTNCLEVBQXVDO0FBQUE7O0FBQ3JDQyxlQUFXLEdBQUdwQixLQUFLLENBQUMwQixlQUFOLENBQXNCK0QsT0FBTyxDQUFDOUQsS0FBOUIsRUFBcUNQLFdBQW5EO0FBQ0EsVUFBTXFCLE9BQU8sR0FBR0MsTUFBTSxDQUFDQyxXQUFQLEVBQWhCOztBQUNBLFFBQ0Usc0JBQUNELE1BQU0sQ0FBQ29FLFFBQVIsc0VBQUMsaUJBQWlCQyxRQUFsQiw0RUFBQyxzQkFBMkJDLEtBQTVCLG1EQUFDLHVCQUFrQ0MsNkJBQW5DLEtBQ0FqSCxLQUFLLENBQUN3Qyx1QkFBTixDQUE4QnBCLFdBQTlCLENBRkYsRUFFOEM7QUFDNUNxRSxhQUFPLENBQUN6QixLQUFSLEdBQWdCLHVCQUFnQjVDLFdBQWhCLG9EQUMyQnFCLE9BRDNCLE1BQWhCO0FBRUFyQixpQkFBVyxHQUFHcUIsT0FBZDtBQUNEO0FBQ0Y7O0FBRUQsUUFBTUYsU0FBUyxHQUFHdkMsS0FBSyxDQUFDc0MsbUJBQU4sQ0FBMEJtRCxPQUFPLENBQUM5RCxLQUFsQyxDQUFsQjs7QUFFQSxNQUFJOEQsT0FBTyxDQUFDekIsS0FBWixFQUFtQjtBQUNqQmpDLE9BQUcsQ0FBQ0MsSUFBSixDQUFTLDZCQUNDeUQsT0FBTyxDQUFDekIsS0FBUixZQUF5QnJELEtBQXpCLEdBQ0E4RSxPQUFPLENBQUN6QixLQUFSLENBQWNGLE9BRGQsR0FDd0IyQixPQUFPLENBQUN6QixLQUZqQyxDQUFUO0FBR0FiLE9BQUcsQ0FBQ3FDLEdBQUosQ0FBUVMsd0JBQXdCLENBQUM7QUFDL0I5RSxnQkFBVSxFQUFFc0UsT0FBTyxDQUFDdEUsVUFEVztBQUUvQm9GLHdCQUFrQixFQUFFLEtBRlc7QUFHL0JuRixpQkFIK0I7QUFJL0JtQjtBQUorQixLQUFELENBQWhDLEVBS0ksT0FMSjtBQU1BO0FBQ0QsR0E3QjJDLENBK0I1QztBQUNBO0FBQ0E7OztBQUNBWSxLQUFHLENBQUNxQyxHQUFKLENBQVFTLHdCQUF3QixDQUFDO0FBQy9COUUsY0FBVSxFQUFFc0UsT0FBTyxDQUFDdEUsVUFEVztBQUUvQm9GLHNCQUFrQixFQUFFLElBRlc7QUFHL0J4RixtQkFBZSxFQUFFMEUsT0FBTyxDQUFDRyxXQUFSLENBQW9CRixLQUhOO0FBSS9CMUUsb0JBQWdCLEVBQUV5RSxPQUFPLENBQUNHLFdBQVIsQ0FBb0JELE1BSlA7QUFLL0J2RSxlQUwrQjtBQU0vQm1CO0FBTitCLEdBQUQsQ0FBaEMsRUFPSSxPQVBKO0FBUUQsQ0ExQ0Q7O0FBNkNBLE1BQU0yRSxlQUFlLEdBQUdDLE9BQU8sQ0FBQyxrQkFBRCxDQUFQLElBQStCQSxPQUFPLENBQUMsa0JBQUQsQ0FBUCxDQUE0QkQsZUFBbkY7O0FBRUEsTUFBTUUsb0JBQW9CLEdBQUcsTUFDM0JGLGVBQWUsSUFBSUEsZUFBZSxDQUFDRyxXQUFoQixFQURyQixDLENBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBckgsS0FBSyxDQUFDc0gsVUFBTixHQUFtQkMsU0FBUyxJQUFJO0FBQzlCLE1BQUlILG9CQUFvQixFQUF4QixFQUNFLE9BQU9GLGVBQWUsQ0FBQ00sSUFBaEIsQ0FBcUJELFNBQXJCLENBQVAsQ0FERixLQUdFLE9BQU9BLFNBQVA7QUFDSCxDQUxELEMsQ0FPQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBdkgsS0FBSyxDQUFDeUgsVUFBTixHQUFtQixDQUFDQyxXQUFELEVBQWNDLE1BQWQsS0FBeUI7QUFDMUMsTUFBSSxDQUFDUixPQUFPLENBQUMsa0JBQUQsQ0FBUixJQUFnQyxDQUFDRCxlQUFlLENBQUNVLFFBQWhCLENBQXlCRixXQUF6QixDQUFyQyxFQUNFLE9BQU9BLFdBQVA7QUFFRixTQUFPUixlQUFlLENBQUNXLElBQWhCLENBQXFCSCxXQUFyQixFQUFrQ0MsTUFBbEMsQ0FBUDtBQUNELENBTEQsQyxDQU9BO0FBQ0E7OztBQUNBM0gsS0FBSyxDQUFDOEgsV0FBTixHQUFvQixDQUFDQyxXQUFELEVBQWNKLE1BQWQsS0FBeUI7QUFDM0MsUUFBTWhCLE1BQU0sR0FBRyxFQUFmO0FBQ0FxQixRQUFNLENBQUNDLElBQVAsQ0FBWUYsV0FBWixFQUF5QkcsT0FBekIsQ0FBaUNDLEdBQUcsSUFDbEN4QixNQUFNLENBQUN3QixHQUFELENBQU4sR0FBY25JLEtBQUssQ0FBQ3lILFVBQU4sQ0FBaUJNLFdBQVcsQ0FBQ0ksR0FBRCxDQUE1QixFQUFtQ1IsTUFBbkMsQ0FEaEI7QUFHQSxTQUFPaEIsTUFBUDtBQUNELENBTkQsQzs7Ozs7Ozs7Ozs7QUNuZEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7QUFDQTtBQUNBM0csS0FBSyxDQUFDb0ksbUJBQU4sR0FBNEIsSUFBSUMsS0FBSyxDQUFDQyxVQUFWLENBQzFCLGlDQUQwQixFQUNTO0FBQ2pDQyxxQkFBbUIsRUFBRTtBQURZLENBRFQsQ0FBNUI7O0FBS0F2SSxLQUFLLENBQUNvSSxtQkFBTixDQUEwQkksV0FBMUIsQ0FBc0MsS0FBdEMsRUFBNkM7QUFBRUMsUUFBTSxFQUFFO0FBQVYsQ0FBN0M7O0FBQ0F6SSxLQUFLLENBQUNvSSxtQkFBTixDQUEwQkksV0FBMUIsQ0FBc0Msa0JBQXRDOztBQUNBeEksS0FBSyxDQUFDb0ksbUJBQU4sQ0FBMEJJLFdBQTFCLENBQXNDLFdBQXRDLEUsQ0FJQTs7O0FBQ0EsTUFBTUUsa0JBQWtCLEdBQUcsTUFBTTtBQUMvQjtBQUNBLFFBQU1DLFVBQVUsR0FBRyxJQUFJQyxJQUFKLEVBQW5CO0FBQ0FELFlBQVUsQ0FBQ0UsVUFBWCxDQUFzQkYsVUFBVSxDQUFDRyxVQUFYLEtBQTBCLENBQWhEOztBQUNBOUksT0FBSyxDQUFDb0ksbUJBQU4sQ0FBMEJXLE1BQTFCLENBQWlDO0FBQUVDLGFBQVMsRUFBRTtBQUFFQyxTQUFHLEVBQUVOO0FBQVA7QUFBYixHQUFqQztBQUNELENBTEQ7O0FBTUEsTUFBTU8sY0FBYyxHQUFHeEcsTUFBTSxDQUFDeUcsV0FBUCxDQUFtQlQsa0JBQW5CLEVBQXVDLEtBQUssSUFBNUMsQ0FBdkIsQyxDQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBMUksS0FBSyxDQUFDNEQsdUJBQU4sR0FBZ0MsVUFBQ3VFLEdBQUQsRUFBTWlCLFVBQU4sRUFBOEM7QUFBQSxNQUE1QnBJLGdCQUE0Qix1RUFBVCxJQUFTO0FBQzVFcUksT0FBSyxDQUFDbEIsR0FBRCxFQUFNbUIsTUFBTixDQUFMO0FBQ0FELE9BQUssQ0FBQ3JJLGdCQUFELEVBQW1CdUksS0FBSyxDQUFDQyxLQUFOLENBQVlGLE1BQVosQ0FBbkIsQ0FBTDs7QUFFQSxNQUFJRixVQUFVLFlBQVl6SSxLQUExQixFQUFpQztBQUMvQnlJLGNBQVUsR0FBR0ssYUFBYSxDQUFDTCxVQUFELENBQTFCO0FBQ0QsR0FGRCxNQUVPO0FBQ0xBLGNBQVUsR0FBR3BKLEtBQUssQ0FBQ3NILFVBQU4sQ0FBaUI4QixVQUFqQixDQUFiO0FBQ0QsR0FSMkUsQ0FVNUU7QUFDQTtBQUNBOzs7QUFDQXBKLE9BQUssQ0FBQ29JLG1CQUFOLENBQTBCc0IsTUFBMUIsQ0FBaUM7QUFDL0J2QjtBQUQrQixHQUFqQyxFQUVHO0FBQ0RBLE9BREM7QUFFRGlCLGNBRkM7QUFHRHBJLG9CQUhDO0FBSURnSSxhQUFTLEVBQUUsSUFBSUosSUFBSjtBQUpWLEdBRkg7QUFRRCxDQXJCRCxDLENBd0JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBNUksS0FBSyxDQUFDaUIsMEJBQU4sR0FBbUMsVUFBQ2tILEdBQUQsRUFBa0M7QUFBQSxNQUE1Qm5ILGdCQUE0Qix1RUFBVCxJQUFTO0FBQ25FcUksT0FBSyxDQUFDbEIsR0FBRCxFQUFNbUIsTUFBTixDQUFMOztBQUVBLFFBQU1LLGlCQUFpQixHQUFHM0osS0FBSyxDQUFDb0ksbUJBQU4sQ0FBMEJwRCxPQUExQixDQUFrQztBQUMxRG1ELE9BRDBEO0FBRTFEbkg7QUFGMEQsR0FBbEMsQ0FBMUI7O0FBS0EsTUFBSTJJLGlCQUFKLEVBQXVCO0FBQ3JCM0osU0FBSyxDQUFDb0ksbUJBQU4sQ0FBMEJXLE1BQTFCLENBQWlDO0FBQUVhLFNBQUcsRUFBRUQsaUJBQWlCLENBQUNDO0FBQXpCLEtBQWpDOztBQUNBLFFBQUlELGlCQUFpQixDQUFDUCxVQUFsQixDQUE2QnBGLEtBQWpDLEVBQ0UsT0FBTzZGLGFBQWEsQ0FBQ0YsaUJBQWlCLENBQUNQLFVBQWxCLENBQTZCcEYsS0FBOUIsQ0FBcEIsQ0FERixLQUdFLE9BQU9oRSxLQUFLLENBQUN5SCxVQUFOLENBQWlCa0MsaUJBQWlCLENBQUNQLFVBQW5DLENBQVA7QUFDSCxHQU5ELE1BTU87QUFDTCxXQUFPdkcsU0FBUDtBQUNEO0FBQ0YsQ0FqQkQsQyxDQW9CQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsTUFBTTRHLGFBQWEsR0FBR3pGLEtBQUssSUFBSTtBQUM3QixRQUFNOEYsV0FBVyxHQUFHLEVBQXBCO0FBQ0E5QixRQUFNLENBQUMrQixtQkFBUCxDQUEyQi9GLEtBQTNCLEVBQWtDa0UsT0FBbEMsQ0FDRUMsR0FBRyxJQUFJMkIsV0FBVyxDQUFDM0IsR0FBRCxDQUFYLEdBQW1CbkUsS0FBSyxDQUFDbUUsR0FBRCxDQURqQyxFQUY2QixDQU03Qjs7QUFDQSxNQUFHbkUsS0FBSyxZQUFZdEIsTUFBTSxDQUFDL0IsS0FBM0IsRUFBa0M7QUFDaENtSixlQUFXLENBQUMsYUFBRCxDQUFYLEdBQTZCLElBQTdCO0FBQ0Q7O0FBRUQsU0FBTztBQUFFOUYsU0FBSyxFQUFFOEY7QUFBVCxHQUFQO0FBQ0QsQ0FaRCxDLENBY0E7OztBQUNBLE1BQU1ELGFBQWEsR0FBR0csUUFBUSxJQUFJO0FBQ2hDLE1BQUloRyxLQUFKOztBQUVBLE1BQUlnRyxRQUFRLENBQUNDLFdBQWIsRUFBMEI7QUFDeEJqRyxTQUFLLEdBQUcsSUFBSXRCLE1BQU0sQ0FBQy9CLEtBQVgsRUFBUjtBQUNBLFdBQU9xSixRQUFRLENBQUNDLFdBQWhCO0FBQ0QsR0FIRCxNQUdPO0FBQ0xqRyxTQUFLLEdBQUcsSUFBSXJELEtBQUosRUFBUjtBQUNEOztBQUVEcUgsUUFBTSxDQUFDK0IsbUJBQVAsQ0FBMkJDLFFBQTNCLEVBQXFDOUIsT0FBckMsQ0FBNkNDLEdBQUcsSUFDOUNuRSxLQUFLLENBQUNtRSxHQUFELENBQUwsR0FBYTZCLFFBQVEsQ0FBQzdCLEdBQUQsQ0FEdkI7QUFJQSxTQUFPbkUsS0FBUDtBQUNELENBZkQsQzs7Ozs7Ozs7Ozs7QUM5R0EsSUFBSWtHLGFBQUo7O0FBQWtCdEssTUFBTSxDQUFDQyxJQUFQLENBQVksc0NBQVosRUFBbUQ7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ21LLGlCQUFhLEdBQUNuSyxDQUFkO0FBQWdCOztBQUE1QixDQUFuRCxFQUFpRixDQUFqRjtBQUFsQkMsS0FBSyxDQUFDeUcsbUJBQU4sR0FBNEIsZ0NBQTVCOztBQUVBekcsS0FBSyxDQUFDbUssWUFBTixHQUFxQixDQUFDdkosV0FBRCxFQUFjMEYsTUFBZCxFQUFzQjhELE1BQXRCLEVBQThCQyxrQkFBOUIsS0FBcUQ7QUFDeEU7QUFDQTtBQUNBO0FBQ0EsTUFBSTlILFNBQVMsR0FBRyxLQUFoQjtBQUNBLE1BQUkrSCxTQUFTLEdBQUcsS0FBaEI7O0FBQ0EsTUFBSUYsTUFBSixFQUFZO0FBQ1ZBLFVBQU0scUJBQVFBLE1BQVIsQ0FBTjtBQUNBN0gsYUFBUyxHQUFHNkgsTUFBTSxDQUFDRyxPQUFuQjtBQUNBRCxhQUFTLEdBQUdGLE1BQU0sQ0FBQ0ksT0FBbkI7QUFDQSxXQUFPSixNQUFNLENBQUNHLE9BQWQ7QUFDQSxXQUFPSCxNQUFNLENBQUNJLE9BQWQ7O0FBQ0EsUUFBSXhDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZbUMsTUFBWixFQUFvQnBILE1BQXBCLEtBQStCLENBQW5DLEVBQXNDO0FBQ3BDb0gsWUFBTSxHQUFHdkgsU0FBVDtBQUNEO0FBQ0Y7O0FBRUQsTUFBSUgsTUFBTSxDQUFDK0gsUUFBUCxJQUFtQmxJLFNBQXZCLEVBQWtDO0FBQ2hDLFVBQU1pQyxHQUFHLEdBQUdrRyxHQUFHLENBQUNDLE9BQUosQ0FBWSxLQUFaLENBQVo7O0FBQ0EsUUFBSUMsT0FBTyxHQUFHQyxPQUFPLENBQUNDLEdBQVIsQ0FBWUMsZUFBWixJQUNSbkUseUJBQXlCLENBQUNvRSxRQURoQzs7QUFHQSxRQUFJVixTQUFKLEVBQWU7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBTVcsYUFBYSxHQUFHekcsR0FBRyxDQUFDdkMsS0FBSixDQUFVMkksT0FBVixDQUF0Qjs7QUFDQSxVQUFJSyxhQUFhLENBQUNDLFFBQWQsS0FBMkIsV0FBL0IsRUFBNEM7QUFDMUNELHFCQUFhLENBQUNDLFFBQWQsR0FBeUIsVUFBekI7QUFDQSxlQUFPRCxhQUFhLENBQUNFLElBQXJCO0FBQ0Q7O0FBQ0RQLGFBQU8sR0FBR3BHLEdBQUcsQ0FBQzRHLE1BQUosQ0FBV0gsYUFBWCxDQUFWO0FBQ0Q7O0FBRURaLHNCQUFrQixtQ0FDYkEsa0JBRGE7QUFFaEI7QUFDQTtBQUNBTztBQUpnQixNQUFsQjtBQU1EOztBQUVELFNBQU9TLEdBQUcsQ0FBQ0MsYUFBSixDQUNMNUksTUFBTSxDQUFDQyxXQUFQLGtCQUE2Qi9CLFdBQTdCLEdBQTRDeUosa0JBQTVDLENBREssRUFFTCxJQUZLLEVBR0xELE1BSEssQ0FBUDtBQUlELENBaERELEMiLCJmaWxlIjoiL3BhY2thZ2VzL29hdXRoLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGJvZHlQYXJzZXIgZnJvbSAnYm9keS1wYXJzZXInO1xuXG5PQXV0aCA9IHt9O1xuT0F1dGhUZXN0ID0ge307XG5cblJvdXRlUG9saWN5LmRlY2xhcmUoJy9fb2F1dGgvJywgJ25ldHdvcmsnKTtcblxuY29uc3QgcmVnaXN0ZXJlZFNlcnZpY2VzID0ge307XG5cbi8vIEludGVybmFsOiBNYXBzIGZyb20gc2VydmljZSB2ZXJzaW9uIHRvIGhhbmRsZXIgZnVuY3Rpb24uIFRoZVxuLy8gJ29hdXRoMScgYW5kICdvYXV0aDInIHBhY2thZ2VzIG1hbmlwdWxhdGUgdGhpcyBkaXJlY3RseSB0byByZWdpc3RlclxuLy8gZm9yIGNhbGxiYWNrcy5cbk9BdXRoLl9yZXF1ZXN0SGFuZGxlcnMgPSB7fTtcblxuXG4vLyBSZWdpc3RlciBhIGhhbmRsZXIgZm9yIGFuIE9BdXRoIHNlcnZpY2UuIFRoZSBoYW5kbGVyIHdpbGwgYmUgY2FsbGVkXG4vLyB3aGVuIHdlIGdldCBhbiBpbmNvbWluZyBodHRwIHJlcXVlc3Qgb24gL19vYXV0aC97c2VydmljZU5hbWV9LiBUaGlzXG4vLyBoYW5kbGVyIHNob3VsZCB1c2UgdGhhdCBpbmZvcm1hdGlvbiB0byBmZXRjaCBkYXRhIGFib3V0IHRoZSB1c2VyXG4vLyBsb2dnaW5nIGluLlxuLy9cbi8vIEBwYXJhbSBuYW1lIHtTdHJpbmd9IGUuZy4gXCJnb29nbGVcIiwgXCJmYWNlYm9va1wiXG4vLyBAcGFyYW0gdmVyc2lvbiB7TnVtYmVyfSBPQXV0aCB2ZXJzaW9uICgxIG9yIDIpXG4vLyBAcGFyYW0gdXJscyAgIEZvciBPQXV0aDEgb25seSwgc3BlY2lmeSB0aGUgc2VydmljZSdzIHVybHNcbi8vIEBwYXJhbSBoYW5kbGVPYXV0aFJlcXVlc3Qge0Z1bmN0aW9uKG9hdXRoQmluZGluZ3xxdWVyeSl9XG4vLyAgIC0gKEZvciBPQXV0aDEgb25seSkgb2F1dGhCaW5kaW5nIHtPQXV0aDFCaW5kaW5nfSBib3VuZCB0byB0aGUgYXBwcm9wcmlhdGUgcHJvdmlkZXJcbi8vICAgLSAoRm9yIE9BdXRoMiBvbmx5KSBxdWVyeSB7T2JqZWN0fSBwYXJhbWV0ZXJzIHBhc3NlZCBpbiBxdWVyeSBzdHJpbmdcbi8vICAgLSByZXR1cm4gdmFsdWUgaXM6XG4vLyAgICAgLSB7c2VydmljZURhdGE6LCAob3B0aW9uYWwgb3B0aW9uczopfSB3aGVyZSBzZXJ2aWNlRGF0YSBzaG91bGQgZW5kXG4vLyAgICAgICB1cCBpbiB0aGUgdXNlcidzIHNlcnZpY2VzW25hbWVdIGZpZWxkXG4vLyAgICAgLSBgbnVsbGAgaWYgdGhlIHVzZXIgZGVjbGluZWQgdG8gZ2l2ZSBwZXJtaXNzaW9uc1xuLy9cbk9BdXRoLnJlZ2lzdGVyU2VydmljZSA9IChuYW1lLCB2ZXJzaW9uLCB1cmxzLCBoYW5kbGVPYXV0aFJlcXVlc3QpID0+IHtcbiAgaWYgKHJlZ2lzdGVyZWRTZXJ2aWNlc1tuYW1lXSlcbiAgICB0aHJvdyBuZXcgRXJyb3IoYEFscmVhZHkgcmVnaXN0ZXJlZCB0aGUgJHtuYW1lfSBPQXV0aCBzZXJ2aWNlYCk7XG5cbiAgcmVnaXN0ZXJlZFNlcnZpY2VzW25hbWVdID0ge1xuICAgIHNlcnZpY2VOYW1lOiBuYW1lLFxuICAgIHZlcnNpb24sXG4gICAgdXJscyxcbiAgICBoYW5kbGVPYXV0aFJlcXVlc3QsXG4gIH07XG59O1xuXG4vLyBGb3IgdGVzdCBjbGVhbnVwLlxuT0F1dGhUZXN0LnVucmVnaXN0ZXJTZXJ2aWNlID0gbmFtZSA9PiB7XG4gIGRlbGV0ZSByZWdpc3RlcmVkU2VydmljZXNbbmFtZV07XG59O1xuXG5cbk9BdXRoLnJldHJpZXZlQ3JlZGVudGlhbCA9IChjcmVkZW50aWFsVG9rZW4sIGNyZWRlbnRpYWxTZWNyZXQpID0+XG4gIE9BdXRoLl9yZXRyaWV2ZVBlbmRpbmdDcmVkZW50aWFsKGNyZWRlbnRpYWxUb2tlbiwgY3JlZGVudGlhbFNlY3JldCk7XG5cblxuLy8gVGhlIHN0YXRlIHBhcmFtZXRlciBpcyBub3JtYWxseSBnZW5lcmF0ZWQgb24gdGhlIGNsaWVudCB1c2luZ1xuLy8gYGJ0b2FgLCBidXQgZm9yIHRlc3RzIHdlIG5lZWQgYSB2ZXJzaW9uIHRoYXQgcnVucyBvbiB0aGUgc2VydmVyLlxuLy9cbk9BdXRoLl9nZW5lcmF0ZVN0YXRlID0gKGxvZ2luU3R5bGUsIGNyZWRlbnRpYWxUb2tlbiwgcmVkaXJlY3RVcmwpID0+IHtcbiAgcmV0dXJuIEJ1ZmZlci5mcm9tKEpTT04uc3RyaW5naWZ5KHtcbiAgICBsb2dpblN0eWxlOiBsb2dpblN0eWxlLFxuICAgIGNyZWRlbnRpYWxUb2tlbjogY3JlZGVudGlhbFRva2VuLFxuICAgIHJlZGlyZWN0VXJsOiByZWRpcmVjdFVybH0pKS50b1N0cmluZygnYmFzZTY0Jyk7XG59O1xuXG5PQXV0aC5fc3RhdGVGcm9tUXVlcnkgPSBxdWVyeSA9PiB7XG4gIGxldCBzdHJpbmc7XG4gIHRyeSB7XG4gICAgc3RyaW5nID0gQnVmZmVyLmZyb20ocXVlcnkuc3RhdGUsICdiYXNlNjQnKS50b1N0cmluZygnYmluYXJ5Jyk7XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICBMb2cud2FybihgVW5hYmxlIHRvIGJhc2U2NCBkZWNvZGUgc3RhdGUgZnJvbSBPQXV0aCBxdWVyeTogJHtxdWVyeS5zdGF0ZX1gKTtcbiAgICB0aHJvdyBlO1xuICB9XG5cbiAgdHJ5IHtcbiAgICByZXR1cm4gSlNPTi5wYXJzZShzdHJpbmcpO1xuICB9IGNhdGNoIChlKSB7XG4gICAgTG9nLndhcm4oYFVuYWJsZSB0byBwYXJzZSBzdGF0ZSBmcm9tIE9BdXRoIHF1ZXJ5OiAke3N0cmluZ31gKTtcbiAgICB0aHJvdyBlO1xuICB9XG59O1xuXG5PQXV0aC5fbG9naW5TdHlsZUZyb21RdWVyeSA9IHF1ZXJ5ID0+IHtcbiAgbGV0IHN0eWxlO1xuICAvLyBGb3IgYmFja3dhcmRzLWNvbXBhdGliaWxpdHkgZm9yIG9sZGVyIGNsaWVudHMsIGNhdGNoIGFueSBlcnJvcnNcbiAgLy8gdGhhdCByZXN1bHQgZnJvbSBwYXJzaW5nIHRoZSBzdGF0ZSBwYXJhbWV0ZXIuIElmIHdlIGNhbid0IHBhcnNlIGl0LFxuICAvLyBzZXQgbG9naW4gc3R5bGUgdG8gcG9wdXAgYnkgZGVmYXVsdC5cbiAgdHJ5IHtcbiAgICBzdHlsZSA9IE9BdXRoLl9zdGF0ZUZyb21RdWVyeShxdWVyeSkubG9naW5TdHlsZTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgc3R5bGUgPSBcInBvcHVwXCI7XG4gIH1cbiAgaWYgKHN0eWxlICE9PSBcInBvcHVwXCIgJiYgc3R5bGUgIT09IFwicmVkaXJlY3RcIikge1xuICAgIHRocm93IG5ldyBFcnJvcihgVW5yZWNvZ25pemVkIGxvZ2luIHN0eWxlOiAke3N0eWxlfWApO1xuICB9XG4gIHJldHVybiBzdHlsZTtcbn07XG5cbk9BdXRoLl9jcmVkZW50aWFsVG9rZW5Gcm9tUXVlcnkgPSBxdWVyeSA9PiB7XG4gIGxldCBzdGF0ZTtcbiAgLy8gRm9yIGJhY2t3YXJkcy1jb21wYXRpYmlsaXR5IGZvciBvbGRlciBjbGllbnRzLCBjYXRjaCBhbnkgZXJyb3JzXG4gIC8vIHRoYXQgcmVzdWx0IGZyb20gcGFyc2luZyB0aGUgc3RhdGUgcGFyYW1ldGVyLiBJZiB3ZSBjYW4ndCBwYXJzZSBpdCxcbiAgLy8gYXNzdW1lIHRoYXQgdGhlIHN0YXRlIHBhcmFtZXRlcidzIHZhbHVlIGlzIHRoZSBjcmVkZW50aWFsIHRva2VuLCBhc1xuICAvLyBpdCB1c2VkIHRvIGJlIGZvciBvbGRlciBjbGllbnRzLlxuICB0cnkge1xuICAgIHN0YXRlID0gT0F1dGguX3N0YXRlRnJvbVF1ZXJ5KHF1ZXJ5KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgcmV0dXJuIHF1ZXJ5LnN0YXRlO1xuICB9XG4gIHJldHVybiBzdGF0ZS5jcmVkZW50aWFsVG9rZW47XG59O1xuXG5PQXV0aC5faXNDb3Jkb3ZhRnJvbVF1ZXJ5ID0gcXVlcnkgPT4ge1xuICB0cnkge1xuICAgIHJldHVybiAhISBPQXV0aC5fc3RhdGVGcm9tUXVlcnkocXVlcnkpLmlzQ29yZG92YTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgLy8gRm9yIGJhY2t3YXJkcy1jb21wYXRpYmlsaXR5IGZvciBvbGRlciBjbGllbnRzLCBjYXRjaCBhbnkgZXJyb3JzXG4gICAgLy8gdGhhdCByZXN1bHQgZnJvbSBwYXJzaW5nIHRoZSBzdGF0ZSBwYXJhbWV0ZXIuIElmIHdlIGNhbid0IHBhcnNlXG4gICAgLy8gaXQsIGFzc3VtZSB0aGF0IHdlIGFyZSBub3Qgb24gQ29yZG92YSwgc2luY2Ugb2xkZXIgTWV0ZW9yIGRpZG4ndFxuICAgIC8vIGRvIENvcmRvdmEuXG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59O1xuXG4vLyBDaGVja3MgaWYgdGhlIGByZWRpcmVjdFVybGAgbWF0Y2hlcyB0aGUgYXBwIGhvc3QuXG4vLyBXZSBleHBvcnQgdGhpcyBmdW5jdGlvbiBzbyB0aGF0IGRldmVsb3BlcnMgY2FuIG92ZXJyaWRlIHRoaXNcbi8vIGJlaGF2aW9yIHRvIGFsbG93IGFwcHMgZnJvbSBleHRlcm5hbCBkb21haW5zIHRvIGxvZ2luIHVzaW5nIHRoZVxuLy8gcmVkaXJlY3QgT0F1dGggZmxvdy5cbk9BdXRoLl9jaGVja1JlZGlyZWN0VXJsT3JpZ2luID0gcmVkaXJlY3RVcmwgPT4ge1xuICBjb25zdCBhcHBIb3N0ID0gTWV0ZW9yLmFic29sdXRlVXJsKCk7XG4gIGNvbnN0IGFwcEhvc3RSZXBsYWNlZExvY2FsaG9zdCA9IE1ldGVvci5hYnNvbHV0ZVVybCh1bmRlZmluZWQsIHtcbiAgICByZXBsYWNlTG9jYWxob3N0OiB0cnVlXG4gIH0pO1xuICByZXR1cm4gKFxuICAgIHJlZGlyZWN0VXJsLnN1YnN0cigwLCBhcHBIb3N0Lmxlbmd0aCkgIT09IGFwcEhvc3QgJiZcbiAgICByZWRpcmVjdFVybC5zdWJzdHIoMCwgYXBwSG9zdFJlcGxhY2VkTG9jYWxob3N0Lmxlbmd0aCkgIT09IGFwcEhvc3RSZXBsYWNlZExvY2FsaG9zdFxuICApO1xufTtcblxuY29uc3QgbWlkZGxld2FyZSA9IChyZXEsIHJlcywgbmV4dCkgPT4ge1xuICBsZXQgcmVxdWVzdERhdGE7XG5cbiAgLy8gTWFrZSBzdXJlIHRvIGNhdGNoIGFueSBleGNlcHRpb25zIGJlY2F1c2Ugb3RoZXJ3aXNlIHdlJ2QgY3Jhc2hcbiAgLy8gdGhlIHJ1bm5lclxuICB0cnkge1xuICAgIGNvbnN0IHNlcnZpY2VOYW1lID0gb2F1dGhTZXJ2aWNlTmFtZShyZXEpO1xuICAgIGlmICghc2VydmljZU5hbWUpIHtcbiAgICAgIC8vIG5vdCBhbiBvYXV0aCByZXF1ZXN0LiBwYXNzIHRvIG5leHQgbWlkZGxld2FyZS5cbiAgICAgIG5leHQoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBzZXJ2aWNlID0gcmVnaXN0ZXJlZFNlcnZpY2VzW3NlcnZpY2VOYW1lXTtcblxuICAgIC8vIFNraXAgZXZlcnl0aGluZyBpZiB0aGVyZSdzIG5vIHNlcnZpY2Ugc2V0IGJ5IHRoZSBvYXV0aCBtaWRkbGV3YXJlXG4gICAgaWYgKCFzZXJ2aWNlKVxuICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmV4cGVjdGVkIE9BdXRoIHNlcnZpY2UgJHtzZXJ2aWNlTmFtZX1gKTtcblxuICAgIC8vIE1ha2Ugc3VyZSB3ZSdyZSBjb25maWd1cmVkXG4gICAgZW5zdXJlQ29uZmlndXJlZChzZXJ2aWNlTmFtZSk7XG5cbiAgICBjb25zdCBoYW5kbGVyID0gT0F1dGguX3JlcXVlc3RIYW5kbGVyc1tzZXJ2aWNlLnZlcnNpb25dO1xuICAgIGlmICghaGFuZGxlcilcbiAgICAgIHRocm93IG5ldyBFcnJvcihgVW5leHBlY3RlZCBPQXV0aCB2ZXJzaW9uICR7c2VydmljZS52ZXJzaW9ufWApO1xuXG4gICAgaWYgKHJlcS5tZXRob2QgPT09ICdHRVQnKSB7XG4gICAgICByZXF1ZXN0RGF0YSA9IHJlcS5xdWVyeTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmVxdWVzdERhdGEgPSByZXEuYm9keTtcbiAgICB9XG5cbiAgICBoYW5kbGVyKHNlcnZpY2UsIHJlcXVlc3REYXRhLCByZXMpO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICAvLyBpZiB3ZSBnb3QgdGhyb3duIGFuIGVycm9yLCBzYXZlIGl0IG9mZiwgaXQgd2lsbCBnZXQgcGFzc2VkIHRvXG4gICAgLy8gdGhlIGFwcHJvcHJpYXRlIGxvZ2luIGNhbGwgKGlmIGFueSkgYW5kIHJlcG9ydGVkIHRoZXJlLlxuICAgIC8vXG4gICAgLy8gVGhlIG90aGVyIG9wdGlvbiB3b3VsZCBiZSB0byBkaXNwbGF5IGl0IGluIHRoZSBwb3B1cCB0YWIgdGhhdFxuICAgIC8vIGlzIHN0aWxsIG9wZW4gYXQgdGhpcyBwb2ludCwgaWdub3JpbmcgdGhlICdjbG9zZScgb3IgJ3JlZGlyZWN0J1xuICAgIC8vIHdlIHdlcmUgcGFzc2VkLiBCdXQgdGhlbiB0aGUgZGV2ZWxvcGVyIHdvdWxkbid0IGJlIGFibGUgdG9cbiAgICAvLyBzdHlsZSB0aGUgZXJyb3Igb3IgcmVhY3QgdG8gaXQgaW4gYW55IHdheS5cbiAgICBpZiAocmVxdWVzdERhdGE/LnN0YXRlICYmIGVyciBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgICB0cnkgeyAvLyBjYXRjaCBhbnkgZXhjZXB0aW9ucyB0byBhdm9pZCBjcmFzaGluZyBydW5uZXJcbiAgICAgICAgT0F1dGguX3N0b3JlUGVuZGluZ0NyZWRlbnRpYWwoT0F1dGguX2NyZWRlbnRpYWxUb2tlbkZyb21RdWVyeShyZXF1ZXN0RGF0YSksIGVycik7XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgLy8gSWdub3JlIHRoZSBlcnJvciBhbmQganVzdCBnaXZlIHVwLiBJZiB3ZSBmYWlsZWQgdG8gc3RvcmUgdGhlXG4gICAgICAgIC8vIGVycm9yLCB0aGVuIHRoZSBsb2dpbiB3aWxsIGp1c3QgZmFpbCB3aXRoIGEgZ2VuZXJpYyBlcnJvci5cbiAgICAgICAgTG9nLndhcm4oXCJFcnJvciBpbiBPQXV0aCBTZXJ2ZXIgd2hpbGUgc3RvcmluZyBwZW5kaW5nIGxvZ2luIHJlc3VsdC5cXG5cIiArXG4gICAgICAgICAgICAgICAgIGVyci5zdGFjayB8fCBlcnIubWVzc2FnZSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gY2xvc2UgdGhlIHBvcHVwLiBiZWNhdXNlIG5vYm9keSBsaWtlcyB0aGVtIGp1c3QgaGFuZ2luZ1xuICAgIC8vIHRoZXJlLiAgd2hlbiBzb21lb25lIHNlZXMgdGhpcyBtdWx0aXBsZSB0aW1lcyB0aGV5IG1pZ2h0XG4gICAgLy8gdGhpbmsgdG8gY2hlY2sgc2VydmVyIGxvZ3MgKHdlIGhvcGU/KVxuICAgIC8vIENhdGNoIGVycm9ycyBiZWNhdXNlIGFueSBleGNlcHRpb24gaGVyZSB3aWxsIGNyYXNoIHRoZSBydW5uZXIuXG4gICAgdHJ5IHtcbiAgICAgIE9BdXRoLl9lbmRPZkxvZ2luUmVzcG9uc2UocmVzLCB7XG4gICAgICAgIHF1ZXJ5OiByZXF1ZXN0RGF0YSxcbiAgICAgICAgbG9naW5TdHlsZTogT0F1dGguX2xvZ2luU3R5bGVGcm9tUXVlcnkocmVxdWVzdERhdGEpLFxuICAgICAgICBlcnJvcjogZXJyXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIExvZy53YXJuKFwiRXJyb3IgZ2VuZXJhdGluZyBlbmQgb2YgbG9naW4gcmVzcG9uc2VcXG5cIiArXG4gICAgICAgICAgICAgICAoZXJyICYmIChlcnIuc3RhY2sgfHwgZXJyLm1lc3NhZ2UpKSk7XG4gICAgfVxuICB9XG59O1xuXG4vLyBMaXN0ZW4gdG8gaW5jb21pbmcgT0F1dGggaHR0cCByZXF1ZXN0c1xuV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2UoJy9fb2F1dGgnLCBib2R5UGFyc2VyLmpzb24oKSk7XG5XZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZSgnL19vYXV0aCcsIGJvZHlQYXJzZXIudXJsZW5jb2RlZCh7IGV4dGVuZGVkOiBmYWxzZSB9KSk7XG5XZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZShtaWRkbGV3YXJlKTtcblxuT0F1dGhUZXN0Lm1pZGRsZXdhcmUgPSBtaWRkbGV3YXJlO1xuXG4vLyBIYW5kbGUgL19vYXV0aC8qIHBhdGhzIGFuZCBleHRyYWN0IHRoZSBzZXJ2aWNlIG5hbWUuXG4vL1xuLy8gQHJldHVybnMge1N0cmluZ3xudWxsfSBlLmcuIFwiZmFjZWJvb2tcIiwgb3IgbnVsbCBpZiB0aGlzIGlzbid0IGFuXG4vLyBvYXV0aCByZXF1ZXN0XG5jb25zdCBvYXV0aFNlcnZpY2VOYW1lID0gcmVxID0+IHtcbiAgLy8gcmVxLnVybCB3aWxsIGJlIFwiL19vYXV0aC88c2VydmljZSBuYW1lPlwiIHdpdGggYW4gb3B0aW9uYWwgXCI/Y2xvc2VcIi5cbiAgY29uc3QgaSA9IHJlcS51cmwuaW5kZXhPZignPycpO1xuICBsZXQgYmFyZVBhdGg7XG4gIGlmIChpID09PSAtMSlcbiAgICBiYXJlUGF0aCA9IHJlcS51cmw7XG4gIGVsc2VcbiAgICBiYXJlUGF0aCA9IHJlcS51cmwuc3Vic3RyaW5nKDAsIGkpO1xuICBjb25zdCBzcGxpdFBhdGggPSBiYXJlUGF0aC5zcGxpdCgnLycpO1xuXG4gIC8vIEFueSBub24tb2F1dGggcmVxdWVzdCB3aWxsIGNvbnRpbnVlIGRvd24gdGhlIGRlZmF1bHRcbiAgLy8gbWlkZGxld2FyZXMuXG4gIGlmIChzcGxpdFBhdGhbMV0gIT09ICdfb2F1dGgnKVxuICAgIHJldHVybiBudWxsO1xuXG4gIC8vIEZpbmQgc2VydmljZSBiYXNlZCBvbiB1cmxcbiAgY29uc3Qgc2VydmljZU5hbWUgPSBzcGxpdFBhdGhbMl07XG4gIHJldHVybiBzZXJ2aWNlTmFtZTtcbn07XG5cbi8vIE1ha2Ugc3VyZSB3ZSdyZSBjb25maWd1cmVkXG5jb25zdCBlbnN1cmVDb25maWd1cmVkID0gc2VydmljZU5hbWUgPT4ge1xuICBpZiAoIVNlcnZpY2VDb25maWd1cmF0aW9uLmNvbmZpZ3VyYXRpb25zLmZpbmRPbmUoe3NlcnZpY2U6IHNlcnZpY2VOYW1lfSkpIHtcbiAgICB0aHJvdyBuZXcgU2VydmljZUNvbmZpZ3VyYXRpb24uQ29uZmlnRXJyb3IoKTtcbiAgfVxufTtcblxuY29uc3QgaXNTYWZlID0gdmFsdWUgPT4ge1xuICAvLyBUaGlzIG1hdGNoZXMgc3RyaW5ncyBnZW5lcmF0ZWQgYnkgYFJhbmRvbS5zZWNyZXRgIGFuZFxuICAvLyBgUmFuZG9tLmlkYC5cbiAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJzdHJpbmdcIiAmJlxuICAgIC9eW2EtekEtWjAtOVxcLV9dKyQvLnRlc3QodmFsdWUpO1xufTtcblxuLy8gSW50ZXJuYWw6IHVzZWQgYnkgdGhlIG9hdXRoMSBhbmQgb2F1dGgyIHBhY2thZ2VzXG5PQXV0aC5fcmVuZGVyT2F1dGhSZXN1bHRzID0gKHJlcywgcXVlcnksIGNyZWRlbnRpYWxTZWNyZXQpID0+IHtcbiAgLy8gRm9yIHRlc3RzLCB3ZSBzdXBwb3J0IHRoZSBgb25seV9jcmVkZW50aWFsX3NlY3JldF9mb3JfdGVzdGBcbiAgLy8gcGFyYW1ldGVyLCB3aGljaCBqdXN0IHJldHVybnMgdGhlIGNyZWRlbnRpYWwgc2VjcmV0IHdpdGhvdXQgYW55XG4gIC8vIHN1cnJvdW5kaW5nIEhUTUwuIChUaGUgdGVzdCBuZWVkcyB0byBiZSBhYmxlIHRvIGVhc2lseSBncmFiIHRoZVxuICAvLyBzZWNyZXQgYW5kIHVzZSBpdCB0byBsb2cgaW4uKVxuICAvL1xuICAvLyBYWFggb25seV9jcmVkZW50aWFsX3NlY3JldF9mb3JfdGVzdCBjb3VsZCBiZSB1c2VmdWwgZm9yIG90aGVyXG4gIC8vIHRoaW5ncyBiZXNpZGUgdGVzdHMsIGxpa2UgY29tbWFuZC1saW5lIGNsaWVudHMuIFdlIHNob3VsZCBnaXZlIGl0IGFcbiAgLy8gcmVhbCBuYW1lIGFuZCBzZXJ2ZSB0aGUgY3JlZGVudGlhbCBzZWNyZXQgaW4gSlNPTi5cblxuICBpZiAocXVlcnkub25seV9jcmVkZW50aWFsX3NlY3JldF9mb3JfdGVzdCkge1xuICAgIHJlcy53cml0ZUhlYWQoMjAwLCB7J0NvbnRlbnQtVHlwZSc6ICd0ZXh0L2h0bWwnfSk7XG4gICAgcmVzLmVuZChjcmVkZW50aWFsU2VjcmV0LCAndXRmLTgnKTtcbiAgfSBlbHNlIHtcbiAgICBjb25zdCBkZXRhaWxzID0ge1xuICAgICAgcXVlcnksXG4gICAgICBsb2dpblN0eWxlOiBPQXV0aC5fbG9naW5TdHlsZUZyb21RdWVyeShxdWVyeSlcbiAgICB9O1xuICAgIGlmIChxdWVyeS5lcnJvcikge1xuICAgICAgZGV0YWlscy5lcnJvciA9IHF1ZXJ5LmVycm9yO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCB0b2tlbiA9IE9BdXRoLl9jcmVkZW50aWFsVG9rZW5Gcm9tUXVlcnkocXVlcnkpO1xuICAgICAgY29uc3Qgc2VjcmV0ID0gY3JlZGVudGlhbFNlY3JldDtcbiAgICAgIGlmICh0b2tlbiAmJiBzZWNyZXQgJiZcbiAgICAgICAgICBpc1NhZmUodG9rZW4pICYmIGlzU2FmZShzZWNyZXQpKSB7XG4gICAgICAgIGRldGFpbHMuY3JlZGVudGlhbHMgPSB7IHRva2VuOiB0b2tlbiwgc2VjcmV0OiBzZWNyZXR9O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZGV0YWlscy5lcnJvciA9IFwiaW52YWxpZF9jcmVkZW50aWFsX3Rva2VuX29yX3NlY3JldFwiO1xuICAgICAgfVxuICAgIH1cblxuICAgIE9BdXRoLl9lbmRPZkxvZ2luUmVzcG9uc2UocmVzLCBkZXRhaWxzKTtcbiAgfVxufTtcblxuLy8gVGhpcyBcInRlbXBsYXRlXCIgKG5vdCBhIHJlYWwgU3BhY2ViYXJzIHRlbXBsYXRlLCBqdXN0IGFuIEhUTUwgZmlsZVxuLy8gd2l0aCBzb21lICMjUExBQ0VIT0xERVIjI3MpIGNvbW11bmljYXRlcyB0aGUgY3JlZGVudGlhbCBzZWNyZXQgYmFja1xuLy8gdG8gdGhlIG1haW4gd2luZG93IGFuZCB0aGVuIGNsb3NlcyB0aGUgcG9wdXAuXG5PQXV0aC5fZW5kT2ZQb3B1cFJlc3BvbnNlVGVtcGxhdGUgPSBBc3NldHMuZ2V0VGV4dChcbiAgXCJlbmRfb2ZfcG9wdXBfcmVzcG9uc2UuaHRtbFwiKTtcblxuT0F1dGguX2VuZE9mUmVkaXJlY3RSZXNwb25zZVRlbXBsYXRlID0gQXNzZXRzLmdldFRleHQoXG4gIFwiZW5kX29mX3JlZGlyZWN0X3Jlc3BvbnNlLmh0bWxcIik7XG5cbi8vIFJlbmRlcnMgdGhlIGVuZCBvZiBsb2dpbiByZXNwb25zZSB0ZW1wbGF0ZSBpbnRvIHNvbWUgSFRNTCBhbmQgSmF2YVNjcmlwdFxuLy8gdGhhdCBjbG9zZXMgdGhlIHBvcHVwIG9yIHJlZGlyZWN0cyBhdCB0aGUgZW5kIG9mIHRoZSBPQXV0aCBmbG93LlxuLy9cbi8vIG9wdGlvbnMgYXJlOlxuLy8gICAtIGxvZ2luU3R5bGUgKFwicG9wdXBcIiBvciBcInJlZGlyZWN0XCIpXG4vLyAgIC0gc2V0Q3JlZGVudGlhbFRva2VuIChib29sZWFuKVxuLy8gICAtIGNyZWRlbnRpYWxUb2tlblxuLy8gICAtIGNyZWRlbnRpYWxTZWNyZXRcbi8vICAgLSByZWRpcmVjdFVybFxuLy8gICAtIGlzQ29yZG92YSAoYm9vbGVhbilcbi8vXG5jb25zdCByZW5kZXJFbmRPZkxvZ2luUmVzcG9uc2UgPSBvcHRpb25zID0+IHtcbiAgLy8gSXQgd291bGQgYmUgbmljZSB0byB1c2UgQmxhemUgaGVyZSwgYnV0IGl0J3MgYSBsaXR0bGUgdHJpY2t5XG4gIC8vIGJlY2F1c2Ugb3VyIG11c3RhY2hlcyB3b3VsZCBiZSBpbnNpZGUgYSA8c2NyaXB0PiB0YWcsIGFuZCBCbGF6ZVxuICAvLyB3b3VsZCB0cmVhdCB0aGUgPHNjcmlwdD4gdGFnIGNvbnRlbnRzIGFzIHRleHQgKGUuZy4gZW5jb2RlICcmJyBhc1xuICAvLyAnJmFtcDsnKS4gU28gd2UganVzdCBkbyBhIHNpbXBsZSByZXBsYWNlLlxuXG4gIGNvbnN0IGVzY2FwZSA9IHMgPT4ge1xuICAgIGlmIChzKSB7XG4gICAgICByZXR1cm4gcy5yZXBsYWNlKC8mL2csIFwiJmFtcDtcIikuXG4gICAgICAgIHJlcGxhY2UoLzwvZywgXCImbHQ7XCIpLlxuICAgICAgICByZXBsYWNlKC8+L2csIFwiJmd0O1wiKS5cbiAgICAgICAgcmVwbGFjZSgvXFxcIi9nLCBcIiZxdW90O1wiKS5cbiAgICAgICAgcmVwbGFjZSgvXFwnL2csIFwiJiN4Mjc7XCIpLlxuICAgICAgICByZXBsYWNlKC9cXC8vZywgXCImI3gyRjtcIik7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBzO1xuICAgIH1cbiAgfTtcblxuICAvLyBFc2NhcGUgZXZlcnl0aGluZyBqdXN0IHRvIGJlIHNhZmUgKHdlJ3ZlIGFscmVhZHkgY2hlY2tlZCB0aGF0IHNvbWVcbiAgLy8gb2YgdGhpcyBkYXRhIC0tIHRoZSB0b2tlbiBhbmQgc2VjcmV0IC0tIGFyZSBzYWZlKS5cbiAgY29uc3QgY29uZmlnID0ge1xuICAgIHNldENyZWRlbnRpYWxUb2tlbjogISEgb3B0aW9ucy5zZXRDcmVkZW50aWFsVG9rZW4sXG4gICAgY3JlZGVudGlhbFRva2VuOiBlc2NhcGUob3B0aW9ucy5jcmVkZW50aWFsVG9rZW4pLFxuICAgIGNyZWRlbnRpYWxTZWNyZXQ6IGVzY2FwZShvcHRpb25zLmNyZWRlbnRpYWxTZWNyZXQpLFxuICAgIHN0b3JhZ2VQcmVmaXg6IGVzY2FwZShPQXV0aC5fc3RvcmFnZVRva2VuUHJlZml4KSxcbiAgICByZWRpcmVjdFVybDogZXNjYXBlKG9wdGlvbnMucmVkaXJlY3RVcmwpLFxuICAgIGlzQ29yZG92YTogISEgb3B0aW9ucy5pc0NvcmRvdmFcbiAgfTtcblxuICBsZXQgdGVtcGxhdGU7XG4gIGlmIChvcHRpb25zLmxvZ2luU3R5bGUgPT09ICdwb3B1cCcpIHtcbiAgICB0ZW1wbGF0ZSA9IE9BdXRoLl9lbmRPZlBvcHVwUmVzcG9uc2VUZW1wbGF0ZTtcbiAgfSBlbHNlIGlmIChvcHRpb25zLmxvZ2luU3R5bGUgPT09ICdyZWRpcmVjdCcpIHtcbiAgICB0ZW1wbGF0ZSA9IE9BdXRoLl9lbmRPZlJlZGlyZWN0UmVzcG9uc2VUZW1wbGF0ZTtcbiAgfSBlbHNlIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoYGludmFsaWQgbG9naW5TdHlsZTogJHtvcHRpb25zLmxvZ2luU3R5bGV9YCk7XG4gIH1cblxuICBjb25zdCByZXN1bHQgPSB0ZW1wbGF0ZS5yZXBsYWNlKC8jI0NPTkZJRyMjLywgSlNPTi5zdHJpbmdpZnkoY29uZmlnKSlcbiAgICAucmVwbGFjZShcbiAgICAgIC8jI1JPT1RfVVJMX1BBVEhfUFJFRklYIyMvLCBfX21ldGVvcl9ydW50aW1lX2NvbmZpZ19fLlJPT1RfVVJMX1BBVEhfUFJFRklYXG4gICAgKTtcblxuICByZXR1cm4gYDwhRE9DVFlQRSBodG1sPlxcbiR7cmVzdWx0fWA7XG59O1xuXG4vLyBXcml0ZXMgYW4gSFRUUCByZXNwb25zZSB0byB0aGUgcG9wdXAgd2luZG93IGF0IHRoZSBlbmQgb2YgYW4gT0F1dGhcbi8vIGxvZ2luIGZsb3cuIEF0IHRoaXMgcG9pbnQsIGlmIHRoZSB1c2VyIGhhcyBzdWNjZXNzZnVsbHkgYXV0aGVudGljYXRlZFxuLy8gdG8gdGhlIE9BdXRoIHNlcnZlciBhbmQgYXV0aG9yaXplZCB0aGlzIGFwcCwgd2UgY29tbXVuaWNhdGUgdGhlXG4vLyBjcmVkZW50aWFsVG9rZW4gYW5kIGNyZWRlbnRpYWxTZWNyZXQgdG8gdGhlIG1haW4gd2luZG93LiBUaGUgbWFpblxuLy8gd2luZG93IG11c3QgcHJvdmlkZSBib3RoIHRoZXNlIHZhbHVlcyB0byB0aGUgRERQIGBsb2dpbmAgbWV0aG9kIHRvXG4vLyBhdXRoZW50aWNhdGUgaXRzIEREUCBjb25uZWN0aW9uLiBBZnRlciBjb21tdW5pY2F0aW5nIHRoZXNlIHZhdWVzIHRvXG4vLyB0aGUgbWFpbiB3aW5kb3csIHdlIGNsb3NlIHRoZSBwb3B1cC5cbi8vXG4vLyBXZSBleHBvcnQgdGhpcyBmdW5jdGlvbiBzbyB0aGF0IGRldmVsb3BlcnMgY2FuIG92ZXJyaWRlIHRoaXNcbi8vIGJlaGF2aW9yLCB3aGljaCBpcyBwYXJ0aWN1bGFybHkgdXNlZnVsIGluLCBmb3IgZXhhbXBsZSwgc29tZSBtb2JpbGVcbi8vIGVudmlyb25tZW50cyB3aGVyZSBwb3B1cHMgYW5kL29yIGB3aW5kb3cub3BlbmVyYCBkb24ndCB3b3JrLiBGb3Jcbi8vIGV4YW1wbGUsIGFuIGFwcCBjb3VsZCBvdmVycmlkZSBgT0F1dGguX2VuZE9mUG9wdXBSZXNwb25zZWAgdG8gcHV0IHRoZVxuLy8gY3JlZGVudGlhbCB0b2tlbiBhbmQgY3JlZGVudGlhbCBzZWNyZXQgaW4gdGhlIHBvcHVwIFVSTCBmb3IgdGhlIG1haW5cbi8vIHdpbmRvdyB0byByZWFkIHRoZW0gdGhlcmUgaW5zdGVhZCBvZiB1c2luZyBgd2luZG93Lm9wZW5lcmAuIElmIHlvdVxuLy8gb3ZlcnJpZGUgdGhpcyBmdW5jdGlvbiwgeW91IHRha2UgcmVzcG9uc2liaWxpdHkgZm9yIHdyaXRpbmcgdG8gdGhlXG4vLyByZXF1ZXN0IGFuZCBjYWxsaW5nIGByZXMuZW5kKClgIHRvIGNvbXBsZXRlIHRoZSByZXF1ZXN0LlxuLy9cbi8vIEFyZ3VtZW50czpcbi8vICAgLSByZXM6IHRoZSBIVFRQIHJlc3BvbnNlIG9iamVjdFxuLy8gICAtIGRldGFpbHM6XG4vLyAgICAgIC0gcXVlcnk6IHRoZSBxdWVyeSBzdHJpbmcgb24gdGhlIEhUVFAgcmVxdWVzdFxuLy8gICAgICAtIGNyZWRlbnRpYWxzOiB7IHRva2VuOiAqLCBzZWNyZXQ6ICogfS4gSWYgcHJlc2VudCwgdGhpcyBmaWVsZFxuLy8gICAgICAgIGluZGljYXRlcyB0aGF0IHRoZSBsb2dpbiB3YXMgc3VjY2Vzc2Z1bC4gUmV0dXJuIHRoZXNlIHZhbHVlc1xuLy8gICAgICAgIHRvIHRoZSBjbGllbnQsIHdobyBjYW4gdXNlIHRoZW0gdG8gbG9nIGluIG92ZXIgRERQLiBJZlxuLy8gICAgICAgIHByZXNlbnQsIHRoZSB2YWx1ZXMgaGF2ZSBiZWVuIGNoZWNrZWQgYWdhaW5zdCBhIGxpbWl0ZWRcbi8vICAgICAgICBjaGFyYWN0ZXIgc2V0IGFuZCBhcmUgc2FmZSB0byBpbmNsdWRlIGluIEhUTUwuXG4vLyAgICAgIC0gZXJyb3I6IGlmIHByZXNlbnQsIGEgc3RyaW5nIG9yIEVycm9yIGluZGljYXRpbmcgYW4gZXJyb3IgdGhhdFxuLy8gICAgICAgIG9jY3VycmVkIGR1cmluZyB0aGUgbG9naW4uIFRoaXMgY2FuIGNvbWUgZnJvbSB0aGUgY2xpZW50IGFuZFxuLy8gICAgICAgIHNvIHNob3VsZG4ndCBiZSB0cnVzdGVkIGZvciBzZWN1cml0eSBkZWNpc2lvbnMgb3IgaW5jbHVkZWQgaW5cbi8vICAgICAgICB0aGUgcmVzcG9uc2Ugd2l0aG91dCBzYW5pdGl6aW5nIGl0IGZpcnN0LiBPbmx5IG9uZSBvZiBgZXJyb3JgXG4vLyAgICAgICAgb3IgYGNyZWRlbnRpYWxzYCBzaG91bGQgYmUgc2V0LlxuT0F1dGguX2VuZE9mTG9naW5SZXNwb25zZSA9IChyZXMsIGRldGFpbHMpID0+IHtcbiAgcmVzLndyaXRlSGVhZCgyMDAsIHsnQ29udGVudC1UeXBlJzogJ3RleHQvaHRtbCd9KTtcblxuICBsZXQgcmVkaXJlY3RVcmw7XG4gIGlmIChkZXRhaWxzLmxvZ2luU3R5bGUgPT09ICdyZWRpcmVjdCcpIHtcbiAgICByZWRpcmVjdFVybCA9IE9BdXRoLl9zdGF0ZUZyb21RdWVyeShkZXRhaWxzLnF1ZXJ5KS5yZWRpcmVjdFVybDtcbiAgICBjb25zdCBhcHBIb3N0ID0gTWV0ZW9yLmFic29sdXRlVXJsKCk7XG4gICAgaWYgKFxuICAgICAgIU1ldGVvci5zZXR0aW5ncz8ucGFja2FnZXM/Lm9hdXRoPy5kaXNhYmxlQ2hlY2tSZWRpcmVjdFVybE9yaWdpbiAmJlxuICAgICAgT0F1dGguX2NoZWNrUmVkaXJlY3RVcmxPcmlnaW4ocmVkaXJlY3RVcmwpKSB7XG4gICAgICBkZXRhaWxzLmVycm9yID0gYHJlZGlyZWN0VXJsICgke3JlZGlyZWN0VXJsfWAgK1xuICAgICAgICBgKSBpcyBub3Qgb24gdGhlIHNhbWUgaG9zdCBhcyB0aGUgYXBwICgke2FwcEhvc3R9KWA7XG4gICAgICByZWRpcmVjdFVybCA9IGFwcEhvc3Q7XG4gICAgfVxuICB9XG5cbiAgY29uc3QgaXNDb3Jkb3ZhID0gT0F1dGguX2lzQ29yZG92YUZyb21RdWVyeShkZXRhaWxzLnF1ZXJ5KTtcblxuICBpZiAoZGV0YWlscy5lcnJvcikge1xuICAgIExvZy53YXJuKFwiRXJyb3IgaW4gT0F1dGggU2VydmVyOiBcIiArXG4gICAgICAgICAgICAgKGRldGFpbHMuZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/XG4gICAgICAgICAgICAgIGRldGFpbHMuZXJyb3IubWVzc2FnZSA6IGRldGFpbHMuZXJyb3IpKTtcbiAgICByZXMuZW5kKHJlbmRlckVuZE9mTG9naW5SZXNwb25zZSh7XG4gICAgICBsb2dpblN0eWxlOiBkZXRhaWxzLmxvZ2luU3R5bGUsXG4gICAgICBzZXRDcmVkZW50aWFsVG9rZW46IGZhbHNlLFxuICAgICAgcmVkaXJlY3RVcmwsXG4gICAgICBpc0NvcmRvdmEsXG4gICAgfSksIFwidXRmLThcIik7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLy8gSWYgd2UgaGF2ZSBhIGNyZWRlbnRpYWxTZWNyZXQsIHJlcG9ydCBpdCBiYWNrIHRvIHRoZSBwYXJlbnRcbiAgLy8gd2luZG93LCB3aXRoIHRoZSBjb3JyZXNwb25kaW5nIGNyZWRlbnRpYWxUb2tlbi4gVGhlIHBhcmVudCB3aW5kb3dcbiAgLy8gdXNlcyB0aGUgY3JlZGVudGlhbFRva2VuIGFuZCBjcmVkZW50aWFsU2VjcmV0IHRvIGxvZyBpbiBvdmVyIEREUC5cbiAgcmVzLmVuZChyZW5kZXJFbmRPZkxvZ2luUmVzcG9uc2Uoe1xuICAgIGxvZ2luU3R5bGU6IGRldGFpbHMubG9naW5TdHlsZSxcbiAgICBzZXRDcmVkZW50aWFsVG9rZW46IHRydWUsXG4gICAgY3JlZGVudGlhbFRva2VuOiBkZXRhaWxzLmNyZWRlbnRpYWxzLnRva2VuLFxuICAgIGNyZWRlbnRpYWxTZWNyZXQ6IGRldGFpbHMuY3JlZGVudGlhbHMuc2VjcmV0LFxuICAgIHJlZGlyZWN0VXJsLFxuICAgIGlzQ29yZG92YSxcbiAgfSksIFwidXRmLThcIik7XG59O1xuXG5cbmNvbnN0IE9BdXRoRW5jcnlwdGlvbiA9IFBhY2thZ2VbXCJvYXV0aC1lbmNyeXB0aW9uXCJdICYmIFBhY2thZ2VbXCJvYXV0aC1lbmNyeXB0aW9uXCJdLk9BdXRoRW5jcnlwdGlvbjtcblxuY29uc3QgdXNpbmdPQXV0aEVuY3J5cHRpb24gPSAoKSA9PlxuICBPQXV0aEVuY3J5cHRpb24gJiYgT0F1dGhFbmNyeXB0aW9uLmtleUlzTG9hZGVkKCk7XG5cbi8vIEVuY3J5cHQgc2Vuc2l0aXZlIHNlcnZpY2UgZGF0YSBzdWNoIGFzIGFjY2VzcyB0b2tlbnMgaWYgdGhlXG4vLyBcIm9hdXRoLWVuY3J5cHRpb25cIiBwYWNrYWdlIGlzIGxvYWRlZCBhbmQgdGhlIG9hdXRoIHNlY3JldCBrZXkgaGFzXG4vLyBiZWVuIHNwZWNpZmllZC4gIFJldHVybnMgdGhlIHVuZW5jcnlwdGVkIHBsYWludGV4dCBvdGhlcndpc2UuXG4vL1xuLy8gVGhlIHVzZXIgaWQgaXMgbm90IHNwZWNpZmllZCBiZWNhdXNlIHRoZSB1c2VyIGlzbid0IGtub3duIHlldCBhdFxuLy8gdGhpcyBwb2ludCBpbiB0aGUgb2F1dGggYXV0aGVudGljYXRpb24gcHJvY2Vzcy4gIEFmdGVyIHRoZSBvYXV0aFxuLy8gYXV0aGVudGljYXRpb24gcHJvY2VzcyBjb21wbGV0ZXMgdGhlIGVuY3J5cHRlZCBzZXJ2aWNlIGRhdGEgZmllbGRzXG4vLyB3aWxsIGJlIHJlLWVuY3J5cHRlZCB3aXRoIHRoZSB1c2VyIGlkIGluY2x1ZGVkIGJlZm9yZSBpbnNlcnRpbmcgdGhlXG4vLyBzZXJ2aWNlIGRhdGEgaW50byB0aGUgdXNlciBkb2N1bWVudC5cbi8vXG5PQXV0aC5zZWFsU2VjcmV0ID0gcGxhaW50ZXh0ID0+IHtcbiAgaWYgKHVzaW5nT0F1dGhFbmNyeXB0aW9uKCkpXG4gICAgcmV0dXJuIE9BdXRoRW5jcnlwdGlvbi5zZWFsKHBsYWludGV4dCk7XG4gIGVsc2VcbiAgICByZXR1cm4gcGxhaW50ZXh0O1xufTtcblxuLy8gVW5lbmNyeXB0IGEgc2VydmljZSBkYXRhIGZpZWxkLCBpZiB0aGUgXCJvYXV0aC1lbmNyeXB0aW9uXCJcbi8vIHBhY2thZ2UgaXMgbG9hZGVkIGFuZCB0aGUgZmllbGQgaXMgZW5jcnlwdGVkLlxuLy9cbi8vIFRocm93cyBhbiBlcnJvciBpZiB0aGUgXCJvYXV0aC1lbmNyeXB0aW9uXCIgcGFja2FnZSBpcyBsb2FkZWQgYW5kIHRoZVxuLy8gZmllbGQgaXMgZW5jcnlwdGVkLCBidXQgdGhlIG9hdXRoIHNlY3JldCBrZXkgaGFzbid0IGJlZW4gc3BlY2lmaWVkLlxuLy9cbk9BdXRoLm9wZW5TZWNyZXQgPSAobWF5YmVTZWNyZXQsIHVzZXJJZCkgPT4ge1xuICBpZiAoIVBhY2thZ2VbXCJvYXV0aC1lbmNyeXB0aW9uXCJdIHx8ICFPQXV0aEVuY3J5cHRpb24uaXNTZWFsZWQobWF5YmVTZWNyZXQpKVxuICAgIHJldHVybiBtYXliZVNlY3JldDtcblxuICByZXR1cm4gT0F1dGhFbmNyeXB0aW9uLm9wZW4obWF5YmVTZWNyZXQsIHVzZXJJZCk7XG59O1xuXG4vLyBVbmVuY3J5cHQgZmllbGRzIGluIHRoZSBzZXJ2aWNlIGRhdGEgb2JqZWN0LlxuLy9cbk9BdXRoLm9wZW5TZWNyZXRzID0gKHNlcnZpY2VEYXRhLCB1c2VySWQpID0+IHtcbiAgY29uc3QgcmVzdWx0ID0ge307XG4gIE9iamVjdC5rZXlzKHNlcnZpY2VEYXRhKS5mb3JFYWNoKGtleSA9PlxuICAgIHJlc3VsdFtrZXldID0gT0F1dGgub3BlblNlY3JldChzZXJ2aWNlRGF0YVtrZXldLCB1c2VySWQpXG4gICk7XG4gIHJldHVybiByZXN1bHQ7XG59O1xuIiwiLy9cbi8vIFdoZW4gYW4gb2F1dGggcmVxdWVzdCBpcyBtYWRlLCBNZXRlb3IgcmVjZWl2ZXMgb2F1dGggY3JlZGVudGlhbHNcbi8vIGluIG9uZSBicm93c2VyIHRhYiwgYW5kIHRlbXBvcmFyaWx5IHBlcnNpc3RzIHRoZW0gd2hpbGUgdGhhdFxuLy8gdGFiIGlzIGNsb3NlZCwgdGhlbiByZXRyaWV2ZXMgdGhlbSBpbiB0aGUgYnJvd3NlciB0YWIgdGhhdFxuLy8gaW5pdGlhdGVkIHRoZSBjcmVkZW50aWFsIHJlcXVlc3QuXG4vL1xuLy8gX3BlbmRpbmdDcmVkZW50aWFscyBpcyB0aGUgc3RvcmFnZSBtZWNoYW5pc20gdXNlZCB0byBzaGFyZSB0aGVcbi8vIGNyZWRlbnRpYWwgYmV0d2VlbiB0aGUgMiB0YWJzXG4vL1xuXG5cbi8vIENvbGxlY3Rpb24gY29udGFpbmluZyBwZW5kaW5nIGNyZWRlbnRpYWxzIG9mIG9hdXRoIGNyZWRlbnRpYWwgcmVxdWVzdHNcbi8vIEhhcyBrZXksIGNyZWRlbnRpYWwsIGFuZCBjcmVhdGVkQXQgZmllbGRzLlxuT0F1dGguX3BlbmRpbmdDcmVkZW50aWFscyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKFxuICBcIm1ldGVvcl9vYXV0aF9wZW5kaW5nQ3JlZGVudGlhbHNcIiwge1xuICAgIF9wcmV2ZW50QXV0b3B1Ymxpc2g6IHRydWVcbiAgfSk7XG5cbk9BdXRoLl9wZW5kaW5nQ3JlZGVudGlhbHMuY3JlYXRlSW5kZXgoJ2tleScsIHsgdW5pcXVlOiB0cnVlIH0pO1xuT0F1dGguX3BlbmRpbmdDcmVkZW50aWFscy5jcmVhdGVJbmRleCgnY3JlZGVudGlhbFNlY3JldCcpO1xuT0F1dGguX3BlbmRpbmdDcmVkZW50aWFscy5jcmVhdGVJbmRleCgnY3JlYXRlZEF0Jyk7XG5cblxuXG4vLyBQZXJpb2RpY2FsbHkgY2xlYXIgb2xkIGVudHJpZXMgdGhhdCB3ZXJlIG5ldmVyIHJldHJpZXZlZFxuY29uc3QgX2NsZWFuU3RhbGVSZXN1bHRzID0gKCkgPT4ge1xuICAvLyBSZW1vdmUgY3JlZGVudGlhbHMgb2xkZXIgdGhhbiAxIG1pbnV0ZVxuICBjb25zdCB0aW1lQ3V0b2ZmID0gbmV3IERhdGUoKTtcbiAgdGltZUN1dG9mZi5zZXRNaW51dGVzKHRpbWVDdXRvZmYuZ2V0TWludXRlcygpIC0gMSk7XG4gIE9BdXRoLl9wZW5kaW5nQ3JlZGVudGlhbHMucmVtb3ZlKHsgY3JlYXRlZEF0OiB7ICRsdDogdGltZUN1dG9mZiB9IH0pO1xufTtcbmNvbnN0IF9jbGVhbnVwSGFuZGxlID0gTWV0ZW9yLnNldEludGVydmFsKF9jbGVhblN0YWxlUmVzdWx0cywgNjAgKiAxMDAwKTtcblxuXG4vLyBTdG9yZXMgdGhlIGtleSBhbmQgY3JlZGVudGlhbCBpbiB0aGUgX3BlbmRpbmdDcmVkZW50aWFscyBjb2xsZWN0aW9uLlxuLy8gV2lsbCB0aHJvdyBhbiBleGNlcHRpb24gaWYgYGtleWAgaXMgbm90IGEgc3RyaW5nLlxuLy9cbi8vIEBwYXJhbSBrZXkge3N0cmluZ31cbi8vIEBwYXJhbSBjcmVkZW50aWFsIHtPYmplY3R9ICAgVGhlIGNyZWRlbnRpYWwgdG8gc3RvcmVcbi8vIEBwYXJhbSBjcmVkZW50aWFsU2VjcmV0IHtzdHJpbmd9IEEgc2VjcmV0IHRoYXQgbXVzdCBiZSBwcmVzZW50ZWQgaW5cbi8vICAgYWRkaXRpb24gdG8gdGhlIGBrZXlgIHRvIHJldHJpZXZlIHRoZSBjcmVkZW50aWFsXG4vL1xuT0F1dGguX3N0b3JlUGVuZGluZ0NyZWRlbnRpYWwgPSAoa2V5LCBjcmVkZW50aWFsLCBjcmVkZW50aWFsU2VjcmV0ID0gbnVsbCkgPT4ge1xuICBjaGVjayhrZXksIFN0cmluZyk7XG4gIGNoZWNrKGNyZWRlbnRpYWxTZWNyZXQsIE1hdGNoLk1heWJlKFN0cmluZykpO1xuXG4gIGlmIChjcmVkZW50aWFsIGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICBjcmVkZW50aWFsID0gc3RvcmFibGVFcnJvcihjcmVkZW50aWFsKTtcbiAgfSBlbHNlIHtcbiAgICBjcmVkZW50aWFsID0gT0F1dGguc2VhbFNlY3JldChjcmVkZW50aWFsKTtcbiAgfVxuXG4gIC8vIFdlIGRvIGFuIHVwc2VydCBoZXJlIGluc3RlYWQgb2YgYW4gaW5zZXJ0IGluIGNhc2UgdGhlIHVzZXIgaGFwcGVuc1xuICAvLyB0byBzb21laG93IHNlbmQgdGhlIHNhbWUgYHN0YXRlYCBwYXJhbWV0ZXIgdHdpY2UgZHVyaW5nIGFuIE9BdXRoXG4gIC8vIGxvZ2luOyB3ZSBkb24ndCB3YW50IGEgZHVwbGljYXRlIGtleSBlcnJvci5cbiAgT0F1dGguX3BlbmRpbmdDcmVkZW50aWFscy51cHNlcnQoe1xuICAgIGtleSxcbiAgfSwge1xuICAgIGtleSxcbiAgICBjcmVkZW50aWFsLFxuICAgIGNyZWRlbnRpYWxTZWNyZXQsXG4gICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpXG4gIH0pO1xufTtcblxuXG4vLyBSZXRyaWV2ZXMgYW5kIHJlbW92ZXMgYSBjcmVkZW50aWFsIGZyb20gdGhlIF9wZW5kaW5nQ3JlZGVudGlhbHMgY29sbGVjdGlvblxuLy9cbi8vIEBwYXJhbSBrZXkge3N0cmluZ31cbi8vIEBwYXJhbSBjcmVkZW50aWFsU2VjcmV0IHtzdHJpbmd9XG4vL1xuT0F1dGguX3JldHJpZXZlUGVuZGluZ0NyZWRlbnRpYWwgPSAoa2V5LCBjcmVkZW50aWFsU2VjcmV0ID0gbnVsbCkgPT4ge1xuICBjaGVjayhrZXksIFN0cmluZyk7XG5cbiAgY29uc3QgcGVuZGluZ0NyZWRlbnRpYWwgPSBPQXV0aC5fcGVuZGluZ0NyZWRlbnRpYWxzLmZpbmRPbmUoe1xuICAgIGtleSxcbiAgICBjcmVkZW50aWFsU2VjcmV0LFxuICB9KTtcblxuICBpZiAocGVuZGluZ0NyZWRlbnRpYWwpIHtcbiAgICBPQXV0aC5fcGVuZGluZ0NyZWRlbnRpYWxzLnJlbW92ZSh7IF9pZDogcGVuZGluZ0NyZWRlbnRpYWwuX2lkIH0pO1xuICAgIGlmIChwZW5kaW5nQ3JlZGVudGlhbC5jcmVkZW50aWFsLmVycm9yKVxuICAgICAgcmV0dXJuIHJlY3JlYXRlRXJyb3IocGVuZGluZ0NyZWRlbnRpYWwuY3JlZGVudGlhbC5lcnJvcik7XG4gICAgZWxzZVxuICAgICAgcmV0dXJuIE9BdXRoLm9wZW5TZWNyZXQocGVuZGluZ0NyZWRlbnRpYWwuY3JlZGVudGlhbCk7XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxufTtcblxuXG4vLyBDb252ZXJ0IGFuIEVycm9yIGludG8gYW4gb2JqZWN0IHRoYXQgY2FuIGJlIHN0b3JlZCBpbiBtb25nb1xuLy8gTm90ZTogQSBNZXRlb3IuRXJyb3IgaXMgcmVjb25zdHJ1Y3RlZCBhcyBhIE1ldGVvci5FcnJvclxuLy8gQWxsIG90aGVyIGVycm9yIGNsYXNzZXMgYXJlIHJlY29uc3RydWN0ZWQgYXMgYSBwbGFpbiBFcnJvci5cbi8vIFRPRE86IENhbiB3ZSBkbyB0aGlzIG1vcmUgc2ltcGx5IHdpdGggRUpTT04/XG5jb25zdCBzdG9yYWJsZUVycm9yID0gZXJyb3IgPT4ge1xuICBjb25zdCBwbGFpbk9iamVjdCA9IHt9O1xuICBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyhlcnJvcikuZm9yRWFjaChcbiAgICBrZXkgPT4gcGxhaW5PYmplY3Rba2V5XSA9IGVycm9yW2tleV1cbiAgKTtcblxuICAvLyBLZWVwIHRyYWNrIG9mIHdoZXRoZXIgaXQncyBhIE1ldGVvci5FcnJvclxuICBpZihlcnJvciBpbnN0YW5jZW9mIE1ldGVvci5FcnJvcikge1xuICAgIHBsYWluT2JqZWN0WydtZXRlb3JFcnJvciddID0gdHJ1ZTtcbiAgfVxuXG4gIHJldHVybiB7IGVycm9yOiBwbGFpbk9iamVjdCB9O1xufTtcblxuLy8gQ3JlYXRlIGFuIGVycm9yIGZyb20gdGhlIGVycm9yIGZvcm1hdCBzdG9yZWQgaW4gbW9uZ29cbmNvbnN0IHJlY3JlYXRlRXJyb3IgPSBlcnJvckRvYyA9PiB7XG4gIGxldCBlcnJvcjtcblxuICBpZiAoZXJyb3JEb2MubWV0ZW9yRXJyb3IpIHtcbiAgICBlcnJvciA9IG5ldyBNZXRlb3IuRXJyb3IoKTtcbiAgICBkZWxldGUgZXJyb3JEb2MubWV0ZW9yRXJyb3I7XG4gIH0gZWxzZSB7XG4gICAgZXJyb3IgPSBuZXcgRXJyb3IoKTtcbiAgfVxuXG4gIE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKGVycm9yRG9jKS5mb3JFYWNoKGtleSA9PlxuICAgIGVycm9yW2tleV0gPSBlcnJvckRvY1trZXldXG4gICk7XG5cbiAgcmV0dXJuIGVycm9yO1xufTtcbiIsIk9BdXRoLl9zdG9yYWdlVG9rZW5QcmVmaXggPSBcIk1ldGVvci5vYXV0aC5jcmVkZW50aWFsU2VjcmV0LVwiO1xuXG5PQXV0aC5fcmVkaXJlY3RVcmkgPSAoc2VydmljZU5hbWUsIGNvbmZpZywgcGFyYW1zLCBhYnNvbHV0ZVVybE9wdGlvbnMpID0+IHtcbiAgLy8gQ2xvbmUgYmVjYXVzZSB3ZSdyZSBnb2luZyB0byBtdXRhdGUgJ3BhcmFtcycuIFRoZSAnY29yZG92YScgYW5kXG4gIC8vICdhbmRyb2lkJyBwYXJhbWV0ZXJzIGFyZSBvbmx5IHVzZWQgZm9yIHBpY2tpbmcgdGhlIGhvc3Qgb2YgdGhlXG4gIC8vIHJlZGlyZWN0IFVSTCwgYW5kIG5vdCBhY3R1YWxseSBpbmNsdWRlZCBpbiB0aGUgcmVkaXJlY3QgVVJMIGl0c2VsZi5cbiAgbGV0IGlzQ29yZG92YSA9IGZhbHNlO1xuICBsZXQgaXNBbmRyb2lkID0gZmFsc2U7XG4gIGlmIChwYXJhbXMpIHtcbiAgICBwYXJhbXMgPSB7IC4uLnBhcmFtcyB9O1xuICAgIGlzQ29yZG92YSA9IHBhcmFtcy5jb3Jkb3ZhO1xuICAgIGlzQW5kcm9pZCA9IHBhcmFtcy5hbmRyb2lkO1xuICAgIGRlbGV0ZSBwYXJhbXMuY29yZG92YTtcbiAgICBkZWxldGUgcGFyYW1zLmFuZHJvaWQ7XG4gICAgaWYgKE9iamVjdC5rZXlzKHBhcmFtcykubGVuZ3RoID09PSAwKSB7XG4gICAgICBwYXJhbXMgPSB1bmRlZmluZWQ7XG4gICAgfVxuICB9XG5cbiAgaWYgKE1ldGVvci5pc1NlcnZlciAmJiBpc0NvcmRvdmEpIHtcbiAgICBjb25zdCB1cmwgPSBOcG0ucmVxdWlyZSgndXJsJyk7XG4gICAgbGV0IHJvb3RVcmwgPSBwcm9jZXNzLmVudi5NT0JJTEVfUk9PVF9VUkwgfHxcbiAgICAgICAgICBfX21ldGVvcl9ydW50aW1lX2NvbmZpZ19fLlJPT1RfVVJMO1xuXG4gICAgaWYgKGlzQW5kcm9pZCkge1xuICAgICAgLy8gTWF0Y2ggdGhlIHJlcGxhY2UgdGhhdCB3ZSBkbyBpbiBjb3Jkb3ZhIGJvaWxlcnBsYXRlXG4gICAgICAvLyAoYm9pbGVycGxhdGUtZ2VuZXJhdG9yIHBhY2thZ2UpLlxuICAgICAgLy8gWFhYIE1heWJlIHdlIHNob3VsZCBwdXQgdGhpcyBpbiBhIHNlcGFyYXRlIHBhY2thZ2Ugb3Igc29tZXRoaW5nXG4gICAgICAvLyB0aGF0IGlzIHVzZWQgaGVyZSBhbmQgYnkgYm9pbGVycGxhdGUtZ2VuZXJhdG9yPyBPciBtYXliZVxuICAgICAgLy8gYE1ldGVvci5hYnNvbHV0ZVVybGAgc2hvdWxkIGtub3cgaG93IHRvIGRvIHRoaXM/XG4gICAgICBjb25zdCBwYXJzZWRSb290VXJsID0gdXJsLnBhcnNlKHJvb3RVcmwpO1xuICAgICAgaWYgKHBhcnNlZFJvb3RVcmwuaG9zdG5hbWUgPT09IFwibG9jYWxob3N0XCIpIHtcbiAgICAgICAgcGFyc2VkUm9vdFVybC5ob3N0bmFtZSA9IFwiMTAuMC4yLjJcIjtcbiAgICAgICAgZGVsZXRlIHBhcnNlZFJvb3RVcmwuaG9zdDtcbiAgICAgIH1cbiAgICAgIHJvb3RVcmwgPSB1cmwuZm9ybWF0KHBhcnNlZFJvb3RVcmwpO1xuICAgIH1cblxuICAgIGFic29sdXRlVXJsT3B0aW9ucyA9IHtcbiAgICAgIC4uLmFic29sdXRlVXJsT3B0aW9ucyxcbiAgICAgIC8vIEZvciBDb3Jkb3ZhIGNsaWVudHMsIHJlZGlyZWN0IHRvIHRoZSBzcGVjaWFsIENvcmRvdmEgcm9vdCB1cmxcbiAgICAgIC8vIChsaWtlbHkgYSBsb2NhbCBJUCBpbiBkZXZlbG9wbWVudCBtb2RlKS5cbiAgICAgIHJvb3RVcmwsXG4gICAgfTtcbiAgfVxuXG4gIHJldHVybiBVUkwuX2NvbnN0cnVjdFVybChcbiAgICBNZXRlb3IuYWJzb2x1dGVVcmwoYF9vYXV0aC8ke3NlcnZpY2VOYW1lfWAsIGFic29sdXRlVXJsT3B0aW9ucyksXG4gICAgbnVsbCxcbiAgICBwYXJhbXMpO1xufTtcbiJdfQ==
