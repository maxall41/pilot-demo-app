(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var OAuth = Package.oauth.OAuth;
var HTTP = Package.http.HTTP;
var HTTPInternals = Package.http.HTTPInternals;
var ServiceConfiguration = Package['service-configuration'].ServiceConfiguration;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var Github;

var require = meteorInstall({"node_modules":{"meteor":{"github-oauth":{"github_server.js":function module(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/github-oauth/github_server.js                                                                    //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
Github = {};
OAuth.registerService('github', 2, null, query => {
  const accessToken = getAccessToken(query);
  const identity = getIdentity(accessToken);
  const emails = getEmails(accessToken);
  const primaryEmail = emails.find(email => email.primary);
  return {
    serviceData: {
      id: identity.id,
      accessToken: OAuth.sealSecret(accessToken),
      email: identity.email || primaryEmail && primaryEmail.email || '',
      username: identity.login,
      emails
    },
    options: {
      profile: {
        name: identity.name
      }
    }
  };
}); // http://developer.github.com/v3/#user-agent-required

let userAgent = "Meteor";
if (Meteor.release) userAgent += "/".concat(Meteor.release);

const getAccessToken = query => {
  const config = ServiceConfiguration.configurations.findOne({
    service: 'github'
  });
  if (!config) throw new ServiceConfiguration.ConfigError();
  let response;

  try {
    response = HTTP.post("https://github.com/login/oauth/access_token", {
      headers: {
        Accept: 'application/json',
        "User-Agent": userAgent
      },
      params: {
        code: query.code,
        client_id: config.clientId,
        client_secret: OAuth.openSecret(config.secret),
        redirect_uri: OAuth._redirectUri('github', config),
        state: query.state
      }
    });
  } catch (err) {
    throw Object.assign(new Error("Failed to complete OAuth handshake with Github. ".concat(err.message)), {
      response: err.response
    });
  }

  if (response.data.error) {
    // if the http response was a json object with an error attribute
    throw new Error("Failed to complete OAuth handshake with GitHub. ".concat(response.data.error));
  } else {
    return response.data.access_token;
  }
};

const getIdentity = accessToken => {
  try {
    return HTTP.get("https://api.github.com/user", {
      headers: {
        "User-Agent": userAgent,
        "Authorization": "token ".concat(accessToken)
      } // http://developer.github.com/v3/#user-agent-required

    }).data;
  } catch (err) {
    throw Object.assign(new Error("Failed to fetch identity from Github. ".concat(err.message)), {
      response: err.response
    });
  }
};

const getEmails = accessToken => {
  try {
    return HTTP.get("https://api.github.com/user/emails", {
      headers: {
        "User-Agent": userAgent,
        "Authorization": "token ".concat(accessToken)
      } // http://developer.github.com/v3/#user-agent-required

    }).data;
  } catch (err) {
    return [];
  }
};

Github.retrieveCredential = (credentialToken, credentialSecret) => OAuth.retrieveCredential(credentialToken, credentialSecret);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

require("/node_modules/meteor/github-oauth/github_server.js");

/* Exports */
Package._define("github-oauth", {
  Github: Github
});

})();

//# sourceURL=meteor://💻app/packages/github-oauth.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvZ2l0aHViLW9hdXRoL2dpdGh1Yl9zZXJ2ZXIuanMiXSwibmFtZXMiOlsiR2l0aHViIiwiT0F1dGgiLCJyZWdpc3RlclNlcnZpY2UiLCJxdWVyeSIsImFjY2Vzc1Rva2VuIiwiZ2V0QWNjZXNzVG9rZW4iLCJpZGVudGl0eSIsImdldElkZW50aXR5IiwiZW1haWxzIiwiZ2V0RW1haWxzIiwicHJpbWFyeUVtYWlsIiwiZmluZCIsImVtYWlsIiwicHJpbWFyeSIsInNlcnZpY2VEYXRhIiwiaWQiLCJzZWFsU2VjcmV0IiwidXNlcm5hbWUiLCJsb2dpbiIsIm9wdGlvbnMiLCJwcm9maWxlIiwibmFtZSIsInVzZXJBZ2VudCIsIk1ldGVvciIsInJlbGVhc2UiLCJjb25maWciLCJTZXJ2aWNlQ29uZmlndXJhdGlvbiIsImNvbmZpZ3VyYXRpb25zIiwiZmluZE9uZSIsInNlcnZpY2UiLCJDb25maWdFcnJvciIsInJlc3BvbnNlIiwiSFRUUCIsInBvc3QiLCJoZWFkZXJzIiwiQWNjZXB0IiwicGFyYW1zIiwiY29kZSIsImNsaWVudF9pZCIsImNsaWVudElkIiwiY2xpZW50X3NlY3JldCIsIm9wZW5TZWNyZXQiLCJzZWNyZXQiLCJyZWRpcmVjdF91cmkiLCJfcmVkaXJlY3RVcmkiLCJzdGF0ZSIsImVyciIsIk9iamVjdCIsImFzc2lnbiIsIkVycm9yIiwibWVzc2FnZSIsImRhdGEiLCJlcnJvciIsImFjY2Vzc190b2tlbiIsImdldCIsInJldHJpZXZlQ3JlZGVudGlhbCIsImNyZWRlbnRpYWxUb2tlbiIsImNyZWRlbnRpYWxTZWNyZXQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsTUFBTSxHQUFHLEVBQVQ7QUFFQUMsS0FBSyxDQUFDQyxlQUFOLENBQXNCLFFBQXRCLEVBQWdDLENBQWhDLEVBQW1DLElBQW5DLEVBQXlDQyxLQUFLLElBQUk7QUFFaEQsUUFBTUMsV0FBVyxHQUFHQyxjQUFjLENBQUNGLEtBQUQsQ0FBbEM7QUFDQSxRQUFNRyxRQUFRLEdBQUdDLFdBQVcsQ0FBQ0gsV0FBRCxDQUE1QjtBQUNBLFFBQU1JLE1BQU0sR0FBR0MsU0FBUyxDQUFDTCxXQUFELENBQXhCO0FBQ0EsUUFBTU0sWUFBWSxHQUFHRixNQUFNLENBQUNHLElBQVAsQ0FBWUMsS0FBSyxJQUFJQSxLQUFLLENBQUNDLE9BQTNCLENBQXJCO0FBRUEsU0FBTztBQUNMQyxlQUFXLEVBQUU7QUFDWEMsUUFBRSxFQUFFVCxRQUFRLENBQUNTLEVBREY7QUFFWFgsaUJBQVcsRUFBRUgsS0FBSyxDQUFDZSxVQUFOLENBQWlCWixXQUFqQixDQUZGO0FBR1hRLFdBQUssRUFBRU4sUUFBUSxDQUFDTSxLQUFULElBQW1CRixZQUFZLElBQUlBLFlBQVksQ0FBQ0UsS0FBaEQsSUFBMEQsRUFIdEQ7QUFJWEssY0FBUSxFQUFFWCxRQUFRLENBQUNZLEtBSlI7QUFLWFY7QUFMVyxLQURSO0FBUUxXLFdBQU8sRUFBRTtBQUFDQyxhQUFPLEVBQUU7QUFBQ0MsWUFBSSxFQUFFZixRQUFRLENBQUNlO0FBQWhCO0FBQVY7QUFSSixHQUFQO0FBVUQsQ0FqQkQsRSxDQW1CQTs7QUFDQSxJQUFJQyxTQUFTLEdBQUcsUUFBaEI7QUFDQSxJQUFJQyxNQUFNLENBQUNDLE9BQVgsRUFDRUYsU0FBUyxlQUFRQyxNQUFNLENBQUNDLE9BQWYsQ0FBVDs7QUFFRixNQUFNbkIsY0FBYyxHQUFHRixLQUFLLElBQUk7QUFDOUIsUUFBTXNCLE1BQU0sR0FBR0Msb0JBQW9CLENBQUNDLGNBQXJCLENBQW9DQyxPQUFwQyxDQUE0QztBQUFDQyxXQUFPLEVBQUU7QUFBVixHQUE1QyxDQUFmO0FBQ0EsTUFBSSxDQUFDSixNQUFMLEVBQ0UsTUFBTSxJQUFJQyxvQkFBb0IsQ0FBQ0ksV0FBekIsRUFBTjtBQUVGLE1BQUlDLFFBQUo7O0FBQ0EsTUFBSTtBQUNGQSxZQUFRLEdBQUdDLElBQUksQ0FBQ0MsSUFBTCxDQUNULDZDQURTLEVBQ3NDO0FBQzdDQyxhQUFPLEVBQUU7QUFDUEMsY0FBTSxFQUFFLGtCQUREO0FBRVAsc0JBQWNiO0FBRlAsT0FEb0M7QUFLN0NjLFlBQU0sRUFBRTtBQUNOQyxZQUFJLEVBQUVsQyxLQUFLLENBQUNrQyxJQUROO0FBRU5DLGlCQUFTLEVBQUViLE1BQU0sQ0FBQ2MsUUFGWjtBQUdOQyxxQkFBYSxFQUFFdkMsS0FBSyxDQUFDd0MsVUFBTixDQUFpQmhCLE1BQU0sQ0FBQ2lCLE1BQXhCLENBSFQ7QUFJTkMsb0JBQVksRUFBRTFDLEtBQUssQ0FBQzJDLFlBQU4sQ0FBbUIsUUFBbkIsRUFBNkJuQixNQUE3QixDQUpSO0FBS05vQixhQUFLLEVBQUUxQyxLQUFLLENBQUMwQztBQUxQO0FBTHFDLEtBRHRDLENBQVg7QUFjRCxHQWZELENBZUUsT0FBT0MsR0FBUCxFQUFZO0FBQ1osVUFBTUMsTUFBTSxDQUFDQyxNQUFQLENBQ0osSUFBSUMsS0FBSiwyREFBNkRILEdBQUcsQ0FBQ0ksT0FBakUsRUFESSxFQUVKO0FBQUVuQixjQUFRLEVBQUVlLEdBQUcsQ0FBQ2Y7QUFBaEIsS0FGSSxDQUFOO0FBSUQ7O0FBQ0QsTUFBSUEsUUFBUSxDQUFDb0IsSUFBVCxDQUFjQyxLQUFsQixFQUF5QjtBQUFFO0FBQ3pCLFVBQU0sSUFBSUgsS0FBSiwyREFBNkRsQixRQUFRLENBQUNvQixJQUFULENBQWNDLEtBQTNFLEVBQU47QUFDRCxHQUZELE1BRU87QUFDTCxXQUFPckIsUUFBUSxDQUFDb0IsSUFBVCxDQUFjRSxZQUFyQjtBQUNEO0FBQ0YsQ0FoQ0Q7O0FBa0NBLE1BQU05QyxXQUFXLEdBQUdILFdBQVcsSUFBSTtBQUNqQyxNQUFJO0FBQ0YsV0FBTzRCLElBQUksQ0FBQ3NCLEdBQUwsQ0FDTCw2QkFESyxFQUMwQjtBQUM3QnBCLGFBQU8sRUFBRTtBQUFDLHNCQUFjWixTQUFmO0FBQTBCLHlDQUEwQmxCLFdBQTFCO0FBQTFCLE9BRG9CLENBQ2dEOztBQURoRCxLQUQxQixFQUdGK0MsSUFITDtBQUlELEdBTEQsQ0FLRSxPQUFPTCxHQUFQLEVBQVk7QUFDWixVQUFNQyxNQUFNLENBQUNDLE1BQVAsQ0FDSixJQUFJQyxLQUFKLGlEQUFtREgsR0FBRyxDQUFDSSxPQUF2RCxFQURJLEVBRUo7QUFBRW5CLGNBQVEsRUFBRWUsR0FBRyxDQUFDZjtBQUFoQixLQUZJLENBQU47QUFJRDtBQUNGLENBWkQ7O0FBY0EsTUFBTXRCLFNBQVMsR0FBR0wsV0FBVyxJQUFJO0FBQy9CLE1BQUk7QUFDRixXQUFPNEIsSUFBSSxDQUFDc0IsR0FBTCxDQUNMLG9DQURLLEVBQ2lDO0FBQ3BDcEIsYUFBTyxFQUFFO0FBQUMsc0JBQWNaLFNBQWY7QUFBMEIseUNBQTBCbEIsV0FBMUI7QUFBMUIsT0FEMkIsQ0FDeUM7O0FBRHpDLEtBRGpDLEVBR0YrQyxJQUhMO0FBSUQsR0FMRCxDQUtFLE9BQU9MLEdBQVAsRUFBWTtBQUNaLFdBQU8sRUFBUDtBQUNEO0FBQ0YsQ0FURDs7QUFXQTlDLE1BQU0sQ0FBQ3VELGtCQUFQLEdBQTRCLENBQUNDLGVBQUQsRUFBa0JDLGdCQUFsQixLQUMxQnhELEtBQUssQ0FBQ3NELGtCQUFOLENBQXlCQyxlQUF6QixFQUEwQ0MsZ0JBQTFDLENBREYsQyIsImZpbGUiOiIvcGFja2FnZXMvZ2l0aHViLW9hdXRoLmpzIiwic291cmNlc0NvbnRlbnQiOlsiR2l0aHViID0ge307XG5cbk9BdXRoLnJlZ2lzdGVyU2VydmljZSgnZ2l0aHViJywgMiwgbnVsbCwgcXVlcnkgPT4ge1xuXG4gIGNvbnN0IGFjY2Vzc1Rva2VuID0gZ2V0QWNjZXNzVG9rZW4ocXVlcnkpO1xuICBjb25zdCBpZGVudGl0eSA9IGdldElkZW50aXR5KGFjY2Vzc1Rva2VuKTtcbiAgY29uc3QgZW1haWxzID0gZ2V0RW1haWxzKGFjY2Vzc1Rva2VuKTtcbiAgY29uc3QgcHJpbWFyeUVtYWlsID0gZW1haWxzLmZpbmQoZW1haWwgPT4gZW1haWwucHJpbWFyeSk7XG5cbiAgcmV0dXJuIHtcbiAgICBzZXJ2aWNlRGF0YToge1xuICAgICAgaWQ6IGlkZW50aXR5LmlkLFxuICAgICAgYWNjZXNzVG9rZW46IE9BdXRoLnNlYWxTZWNyZXQoYWNjZXNzVG9rZW4pLFxuICAgICAgZW1haWw6IGlkZW50aXR5LmVtYWlsIHx8IChwcmltYXJ5RW1haWwgJiYgcHJpbWFyeUVtYWlsLmVtYWlsKSB8fCAnJyxcbiAgICAgIHVzZXJuYW1lOiBpZGVudGl0eS5sb2dpbixcbiAgICAgIGVtYWlscyxcbiAgICB9LFxuICAgIG9wdGlvbnM6IHtwcm9maWxlOiB7bmFtZTogaWRlbnRpdHkubmFtZX19XG4gIH07XG59KTtcblxuLy8gaHR0cDovL2RldmVsb3Blci5naXRodWIuY29tL3YzLyN1c2VyLWFnZW50LXJlcXVpcmVkXG5sZXQgdXNlckFnZW50ID0gXCJNZXRlb3JcIjtcbmlmIChNZXRlb3IucmVsZWFzZSlcbiAgdXNlckFnZW50ICs9IGAvJHtNZXRlb3IucmVsZWFzZX1gO1xuXG5jb25zdCBnZXRBY2Nlc3NUb2tlbiA9IHF1ZXJ5ID0+IHtcbiAgY29uc3QgY29uZmlnID0gU2VydmljZUNvbmZpZ3VyYXRpb24uY29uZmlndXJhdGlvbnMuZmluZE9uZSh7c2VydmljZTogJ2dpdGh1Yid9KTtcbiAgaWYgKCFjb25maWcpXG4gICAgdGhyb3cgbmV3IFNlcnZpY2VDb25maWd1cmF0aW9uLkNvbmZpZ0Vycm9yKCk7XG5cbiAgbGV0IHJlc3BvbnNlO1xuICB0cnkge1xuICAgIHJlc3BvbnNlID0gSFRUUC5wb3N0KFxuICAgICAgXCJodHRwczovL2dpdGh1Yi5jb20vbG9naW4vb2F1dGgvYWNjZXNzX3Rva2VuXCIsIHtcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgIEFjY2VwdDogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICAgIFwiVXNlci1BZ2VudFwiOiB1c2VyQWdlbnRcbiAgICAgICAgfSxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgY29kZTogcXVlcnkuY29kZSxcbiAgICAgICAgICBjbGllbnRfaWQ6IGNvbmZpZy5jbGllbnRJZCxcbiAgICAgICAgICBjbGllbnRfc2VjcmV0OiBPQXV0aC5vcGVuU2VjcmV0KGNvbmZpZy5zZWNyZXQpLFxuICAgICAgICAgIHJlZGlyZWN0X3VyaTogT0F1dGguX3JlZGlyZWN0VXJpKCdnaXRodWInLCBjb25maWcpLFxuICAgICAgICAgIHN0YXRlOiBxdWVyeS5zdGF0ZVxuICAgICAgICB9XG4gICAgICB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgdGhyb3cgT2JqZWN0LmFzc2lnbihcbiAgICAgIG5ldyBFcnJvcihgRmFpbGVkIHRvIGNvbXBsZXRlIE9BdXRoIGhhbmRzaGFrZSB3aXRoIEdpdGh1Yi4gJHtlcnIubWVzc2FnZX1gKSxcbiAgICAgIHsgcmVzcG9uc2U6IGVyci5yZXNwb25zZSB9LFxuICAgICk7XG4gIH1cbiAgaWYgKHJlc3BvbnNlLmRhdGEuZXJyb3IpIHsgLy8gaWYgdGhlIGh0dHAgcmVzcG9uc2Ugd2FzIGEganNvbiBvYmplY3Qgd2l0aCBhbiBlcnJvciBhdHRyaWJ1dGVcbiAgICB0aHJvdyBuZXcgRXJyb3IoYEZhaWxlZCB0byBjb21wbGV0ZSBPQXV0aCBoYW5kc2hha2Ugd2l0aCBHaXRIdWIuICR7cmVzcG9uc2UuZGF0YS5lcnJvcn1gKTtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gcmVzcG9uc2UuZGF0YS5hY2Nlc3NfdG9rZW47XG4gIH1cbn07XG5cbmNvbnN0IGdldElkZW50aXR5ID0gYWNjZXNzVG9rZW4gPT4ge1xuICB0cnkge1xuICAgIHJldHVybiBIVFRQLmdldChcbiAgICAgIFwiaHR0cHM6Ly9hcGkuZ2l0aHViLmNvbS91c2VyXCIsIHtcbiAgICAgICAgaGVhZGVyczoge1wiVXNlci1BZ2VudFwiOiB1c2VyQWdlbnQsIFwiQXV0aG9yaXphdGlvblwiOiBgdG9rZW4gJHthY2Nlc3NUb2tlbn1gfSwgLy8gaHR0cDovL2RldmVsb3Blci5naXRodWIuY29tL3YzLyN1c2VyLWFnZW50LXJlcXVpcmVkXG4gICAgICB9KS5kYXRhO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICB0aHJvdyBPYmplY3QuYXNzaWduKFxuICAgICAgbmV3IEVycm9yKGBGYWlsZWQgdG8gZmV0Y2ggaWRlbnRpdHkgZnJvbSBHaXRodWIuICR7ZXJyLm1lc3NhZ2V9YCksXG4gICAgICB7IHJlc3BvbnNlOiBlcnIucmVzcG9uc2UgfSxcbiAgICApO1xuICB9XG59O1xuXG5jb25zdCBnZXRFbWFpbHMgPSBhY2Nlc3NUb2tlbiA9PiB7XG4gIHRyeSB7XG4gICAgcmV0dXJuIEhUVFAuZ2V0KFxuICAgICAgXCJodHRwczovL2FwaS5naXRodWIuY29tL3VzZXIvZW1haWxzXCIsIHtcbiAgICAgICAgaGVhZGVyczoge1wiVXNlci1BZ2VudFwiOiB1c2VyQWdlbnQsIFwiQXV0aG9yaXphdGlvblwiOiBgdG9rZW4gJHthY2Nlc3NUb2tlbn1gfSwgLy8gaHR0cDovL2RldmVsb3Blci5naXRodWIuY29tL3YzLyN1c2VyLWFnZW50LXJlcXVpcmVkXG4gICAgICB9KS5kYXRhO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICByZXR1cm4gW107XG4gIH1cbn07XG5cbkdpdGh1Yi5yZXRyaWV2ZUNyZWRlbnRpYWwgPSAoY3JlZGVudGlhbFRva2VuLCBjcmVkZW50aWFsU2VjcmV0KSA9PlxuICBPQXV0aC5yZXRyaWV2ZUNyZWRlbnRpYWwoY3JlZGVudGlhbFRva2VuLCBjcmVkZW50aWFsU2VjcmV0KTtcbiJdfQ==
