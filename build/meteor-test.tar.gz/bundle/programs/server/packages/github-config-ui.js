(function () {



/* Exports */
Package._define("github-config-ui");

})();
